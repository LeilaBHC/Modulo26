import pgzrun
import pgzero
from pgzero.animation import animate
from pgzero.loaders import sounds

from pgzhelper import *
from random import *

TITLE = 'Plongeur'
WIDTH = 800
HEIGHT = 600

show_rules = True   # Règles du jeu
start_time = 0

score = 0
game_over = False
game_won = False
protection = False
protection_timer = 0
turbo_used = False
turbo_timer = 0
protection = False
protection_timer = 0
max_time = 60

requins = []
poissons = []
dauphins = []


class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = [f'plongeur_{i}' for i in range(4)]
        self.scale = 0.4
        self.speed = 4
        self.vie = 7
        self.score = 0
        self.game_over = False
        self.game_won = False

    def update(self):
        if keyboard.a:
            self.x -= self.speed
            self.flip_x = True
        if keyboard.d:
            self.x += self.speed
            self.flip_x = False

        if keyboard.w:
            self.y -= self.speed
        if keyboard.s:
            self.y += self.speed

        self.x = max(0, min(WIDTH, self.x))
        self.y = max(0, min(HEIGHT, self.y))

        global turbo_used, turbo_timer, protection, protection_timer

        if keyboard.space and not turbo_used:
            self.speed *= 2
            turbo_used = True
            turbo_timer = time.time()

        for Dauphin in dauphins:
            if self.colliderect(Dauphin) and not protection:
                sounds.protection.play()
                protection = True
                protection_timer = time.time()


        for Requin in requins :
            if self.collides_with(Requin) and not protection:
                sounds.pafff.play()
                self.vie -= 2
                self.x += 60
                self.y -= 60
                if self.vie <= 0 :
                    self.game_over = True
                    sounds.over.play()
                break                       #pour n'avoir qu'une collison par frame

        for Poisson in poissons:
            if self.collides_with(Poisson) and not protection:
                sounds.pafff.play()
                self.vie -= 1
                self.x += 50
                self.y -= 50
                if self.vie <= 0 :
                    self.game_over = True
                    sounds.over.play()
                break


class Requin(Actor):
    def __init__(self, image, pos, **kwargs) :
        super().__init__(image, pos, **kwargs)
        self.image = 'requin'
        self.scale = 0.4
        self.speed = 5
        self.x = -100
        self.y = randint(100, HEIGHT - 50)


    def update(self):
        self.move_in_direction(self.speed)
        self.x += 1



class Poisson(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.image = 'poisson'
        self.scale = 0.15
        self.speed = 2
        self.x = -100
        self.y = randint(100, HEIGHT - 50)

    def update(self):
        self.move_in_direction(self.speed)
        self.x += 1


class Dauphin(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images=['dauphin_1', 'dauphin_2']
        self.scale = 0.4
        self.speed = 3
        self.x = - 100
        self.y = randint(100, HEIGHT - 50)

    def update(self):
        self.move_in_direction(self.speed)
        self.x += 1
        self.flip_x = True



class Perle_doree(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.image = ('perle_doree')
        self.scale = 0.1
        self.pos = (randint(10, WIDTH - 10), randint(100, HEIGHT - 10))


class Perle_argentee(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.image = ('perle_argentee')
        self.scale = 0.2
        self.pos = (randint(10, WIDTH - 10), randint(100, HEIGHT - 10))


player = Player('plongeur_0', (WIDTH - 50, HEIGHT - 50))
requins.append(Requin('requin', (randint(0, WIDTH), randint(100, HEIGHT - 50))))
poissons.append(Poisson('poisson', (randint(0, WIDTH), randint(100, HEIGHT - 50))))
dauphins.append(Dauphin('dauphin_1', (randint(0, WIDTH), randint(100, HEIGHT - 50))))
perle_argentee = Perle_argentee('perle_argentee', (randint(10, WIDTH - 10), randint(100, HEIGHT - 10)))
perle_doree = Perle_doree('perle_doree', (randint(10, WIDTH - 10), randint(100, HEIGHT - 10)))

perle_active = choice([
    Perle_doree('perle_doree', (randint(10, WIDTH - 10), randint(100, HEIGHT - 10))),
    Perle_argentee('perle_argentee', (randint(10, WIDTH - 10), randint(100, HEIGHT - 10)))
])

music.play('underwater')

def add_requin():
    requins.append(Requin('requin', (randint(0, WIDTH), randint(100, HEIGHT - 50))))

def add_poisson():
    poissons.append(Poisson('poisson', (randint(0, WIDTH), randint(100, HEIGHT - 50))))

def add_dauphin():
    dauphin = Dauphin('dauphin_1', (randint(0, WIDTH), randint(100, HEIGHT - 50)))
    dauphins.append(dauphin)


clock.schedule_interval(add_requin, randint(3, 5))
clock.schedule_interval(add_poisson, randint(2, 4))
clock.schedule_interval(add_dauphin, randint(20, 30))


def reset_game():
    global show_rules, start_time, score, protection, protection_timer, turbo_used, turbo_timer, max_time
    global perle_active

    score = 0    #réinitialiser
    max_time = 60
    start_time = time.time()
    protection = False
    protection_timer = 0
    turbo_used = False
    turbo_timer = 0
    player.flip_x = True

    sounds.over.stop()
    sounds.win.stop()
    music.stop()
    music.play('underwater')

    dauphins.clear()    #réinitialiser les animaux
    requins.clear()
    poissons.clear()

    player.vie = 7      #remettre le plongeur à l'état initial
    player.score = 0
    player.x = WIDTH - 50
    player.y = HEIGHT - 50
    player.speed = 4
    player.game_over = False
    player.game_won = False

    perle_active = choice([
        Perle_doree('perle_doree', (randint(10, WIDTH - 10), randint(100, HEIGHT - 10))),
        Perle_argentee('perle_argentee', (randint(10, WIDTH - 10), randint(100, HEIGHT - 10)))
    ])


def draw() :
    if show_rules:
        screen.fill(color=(174, 214, 241))
        screen.draw.text("RÈGLES DU JEU", center=(WIDTH // 2, 100), fontsize=50, color=(25, 25, 112))
        screen.draw.text("- Ramasser des perles pour gagner des points", center=(WIDTH // 2, 150), fontsize=30, color=(25, 25, 112))
        screen.draw.text("les dorées rapportent 3 points et les argentées rapportent 1 point", center=(WIDTH // 2, 170), fontsize=30, color=(25, 25, 112))
        screen.draw.text("- Ne t'approche pas des requins au risque de perdre 2 vies", center=(WIDTH // 2, 210), fontsize=30, color=(25, 25, 112))
        screen.draw.text(" ni des poissons au risque de perdre 1 vie", center=(WIDTH // 2, 230), fontsize=30, color=(25, 25, 112))
        screen.draw.text("- Va vers les dauphins, pour qu'ils t'offrent une protection de 7 sec", center=(WIDTH // 2, 270), fontsize=30, color=(25, 25, 112))
        screen.draw.text("- Appuie sur la touche Espace pour avoir un turbo de 5 sec", center=(WIDTH // 2, 310), fontsize=30, color=(25, 25, 112))
        screen.draw.text(" Attention tu n'as le droit qu'à 1 seul turbo au cours de la partie", center=(WIDTH // 2, 330), fontsize=25, color=(160, 64, 0))
        screen.draw.text("- BUT : GAGNER 50 POINTS EN MAX 60 SECONDES", center=(WIDTH // 2, 400), fontsize=40, color=(25, 25, 112))
        screen.draw.text("Appuie sur ENTER pour commencer", center=(WIDTH // 2, 470), fontsize=30, color=(160, 64, 0))
        return


    temps_restant = max(0, int(max_time - (time.time() - start_time)))
    fond = Actor('fond_marin')
    fond._surf = pygame.transform.scale(fond._surf, (WIDTH, HEIGHT))
    fond.draw()
    screen.draw.text(f'Vie:{player.vie}', (15, 10), color=(25, 25, 112), fontsize=40)
    screen.draw.text(f'Score: {player.score}', (15, 40), color=(25, 25, 112), fontsize=40)
    screen.draw.text(f"Temps: {temps_restant}s", (585, 10), color=(25, 25, 112), fontsize=40)

    if player.game_over:
        screen.fill(color=(205, 97, 85))
        screen.draw.text('Game Over', centerx=400, centery=270, color=(255,255,255), fontsize=60)
        return

    if player.game_won:
        screen.fill(color=(22, 160, 133))
        screen.draw.text('Winner', centerx=400, centery=270, color=(255,255,255), fontsize=100,)
        return

    player.draw()
    perle_active.draw()

    global protection, protection_timer

    if protection:
        bulle = Actor('bulle', center=(player.x, player.y))
        bulle.scale = 0.2
        bulle.draw()
        temps_protection = int(7 - (time.time() - protection_timer))
        screen.draw.text(f'{temps_protection}s', midtop=(player.x, player.y - 60), fontsize=25, color=(160, 64, 0))

    for Requin in requins:
        Requin.draw()

    for Poisson in poissons:
        Poisson.draw()

    for dauphin in dauphins:
        dauphin.draw()


def update():
    global show_rules, start_time
    if show_rules:
        if keyboard.RETURN:
            sounds.start.play()
            show_rules = False
            start_time = time.time()
            player.flip_x = True
            add_poisson()
            add_requin()
            add_dauphin()

            dauphins.clear()  # réinitialiser les animaux pour pas que ça conte les animaux apparus pendant les règles du jeu
            requins.clear()
            poissons.clear()
        return

    if player.game_over or player.game_won:
        if keyboard.RETURN:
            reset_game()
        return

    player.update()

    if keyboard.a or keyboard.d or keyboard.w or keyboard.s :
        player.animate(10)

    global perle_active
    if player.colliderect(perle_active) :
        if perle_active.image == 'perle_doree' :
            player.score += 3
            sounds.perles.play()
            if player.score >= 50 :
                player.game_won = True
                sounds.win.play()

        else:
            player.score += 1
            sounds.perles.play()
            if player.score >= 50 :
                player.game_won = True
                sounds.win.play()

        perle_active.pos = (randint(0, WIDTH), randint(50, HEIGHT))
        perle_active = choice([
            Perle_doree('perle_doree', perle_active.pos),
            Perle_argentee('perle_argentee', perle_active.pos)
        ])

    if turbo_used and time.time() - turbo_timer > 5:
        player.speed = 4

    global protection, protection_timer
    if protection and time.time() - protection_timer > 7:
        protection = False


    for dauphin in dauphins:
        dauphin.update()
        dauphin.animate(10)

    for ennemi in requins:
        ennemi.update()

    for ennemi in poissons :
        ennemi.update()

    if time.time() - start_time >= max_time:
        player.game_over = True
        sounds.over.play()


pgzrun.go()