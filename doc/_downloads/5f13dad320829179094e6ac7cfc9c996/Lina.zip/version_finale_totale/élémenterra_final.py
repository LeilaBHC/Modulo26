# permet d'importer des images pour qu'elles soient ouvertes durant l'histoire
from PIL import Image
# permet d'importer un timer afin de séparer l'apparition des dialogues durant l'histoire et de fluidifier la lecture du joueur
import time

# variable pour stocker la valeur des vies
vie = 3
# variable pour stocker le contenu de l'inventaire
inventaire = []
# variable permettant au joueur d'entrer son nom/pseudo pour qu'il soit réutilisé tout au long du jeu
prenom = input ("avant de commencer, comment vous appelez vous ? ")


# --------------------------------------------------------------------------------------------------------------

# fonction qui représente la variante de l'histoire qui est sélectionnée par le joueur
def terre ():
# permet de réutiliser la variable "vie" dans la fonction 
    global vie
# permet de réutiliser la variable "inventaire" dans la fonction 
    global inventaire


# fonction qui définit le commencement de l'histoire sélectionnée par le joueur
    def bienvenue_terre ():
# permet de faire une "pause" de quelques secondes entre l'apparition du texte final de la phase introductive et le début de cette fonction
        time.sleep(2)
        print ("Vous rejoignez le clan de la terre, recevez cette broche en cristal de roche pour votre intégration au clan.")
        time.sleep(1.5)
# permet de faire entrer un objet dans l'inventaire du joueur
        inventaire.append ("broche de crystal de roche")
        time.sleep(1)
# permet de faire apparaître l'inventaire
        print (inventaire)
        time.sleep(2)
        print ("Femme inconnue: 'Bonjour voyageur je suis Gaïa, régente du clan de la terre. Suis moi pour découvrir tes quartiers.'")
        time.sleep(2)
       

        print ("'Bien",prenom,"bienvenue dans la caverne du clan de la terre.'")
        time.sleep(1)
# permet d'ouvrir une image lors du récit de l'hitoire
        Image.open('caverne.jpg').show()  
        time.sleep(6)
   
        print ("'Ici nous vivons en harmonie avec mère nature, elle nous prodigue tout ce dont nous avons besoin.'")
        time.sleep(4)
        print ("'nous fonctionnons sous 3 classes: les paysans, que tu vois aux abords des rizières, les intelectuels, terrés dans leur maison à s'instruire et les guerriers de la lande.'")
        time.sleep(5)


# fonction qui définit le rôle du joueur dans l'histoire et le choix de son arme
    def guerrier_terre ():
        print ("'Tu m'a l'air d'être un guerrier. Tu feras tes preuves en compagnie du commandant Adam.'")
        time.sleep(3)
        print ("'Maintenant suis moi dans l'armurerie, il te faut une arme.'")
        time.sleep(2)
        Image.open('armurerie.jpg').show()
        time.sleep(6)
        print ("'Tu as le choix entre une lance en trident, un arc de bois béni et un écu dentelé.'")
        time.sleep(2)
        Image.open('armes.jpg').show()
        time.sleep(6)
# variable qui utilise la réponse du joueur pour définir sur quelle arme se porte son choix
        arme = input ("quelle arme choisis-tu ? (lance, arc, écu) ")
# boucle qui empèche le joueur d'entrer un choix qui n'est pas dans la liste proposée
        while arme not in ["lance", "arc", "écu"]:
            arme = input ("cette arme ne fais pas partie des choix. choisis une arme: ")
# condition qui permet de faire apparaître le choix du joueur dans son inventaire
        if arme == ("lance"):
            inventaire.append ("lance")
        elif arme == ("arc"):
            inventaire.append ("arc")
        elif arme == ("écu"):
            inventaire.append ("écu")
        time.sleep(2)
        print (inventaire)


# fonction qui définit la partie de l'histoire où le joueur part à l'aventure
    def aventure_terre ():
        print ("Gaïa: 'je vous laisse maintenant avec le commandant Adam'")
        time.sleep(2)
        print ("Commandant Adam: 'suis moi",prenom,"nous partons protégér la Lande'")
        time.sleep(2)
        Image.open('lande.jpg').show()
        time.sleep(5)
       
        print ("Sur le chemin vous rencontrez un golem de crystal très agressif")
        time.sleep(2)
        print ("Il menace de dévaster la lande et se dirige droit vers la caverne du clan de la terre !!!")
        time.sleep(2)
        Image.open('golem.jpg').show()
        time.sleep(5)
        print ("Vite",prenom,"il faut agir!")
        time.sleep(2)
        print ("Vous vous saisissez de votre arme et attaquez le golem.")
        time.sleep(2)


# fonction qui définit les différentes fins possibles de cette variante de l'histoire
    def fin_terre ():
# permet de réutiliser l'inventaire dans cette fonction-ci puisqu'il sera affecté par la suite
        global inventaire
# condition qui permet au joueur de gagner ou de perdre si un certain item se trouve dans son inventaire
        if "écu" in inventaire:
            print ("Vous lancez l'écu en visant la jambe du golem. La lame du bouclier tranche la pierre qui constitue sa jambe. Il tombe à terre. Vous venez de sauver la lande!")
            time.sleep(2)
            print ("Le Commandant Adam vous félicite et vous ramène à la caverne ou vous rejoignez Gaïa.")
            time.sleep(4)
            print ("Gaïa: '",prenom,"! Vous avez sauvé la lande et la caverne! Vous avez passé le test des guerriers. Vous faites officielement partie du clan de la terre. Vous pouvez vivre une vie heureuse sur Élémenterra'")
            time.sleep(5)
# permet de mettre fin au jeu
            exit()
        else:
# permet de réutiliser la variable vie dans cette fonction puisqu'elle sera affectée
            global vie
            print ("Mauvaise pioche! Vous avez énervé le golem et il vous a écrasé! -1 vie!")
            time.sleep(3)
# permet de changer la valeur de la variable au cours du jeu
            vie=vie-1
            print ("il vous reste",vie,"vie(s)")
            time.sleep(2)
# condition(s) qui permettent au joueur de connaitre son nombre de vies restantes et sa "mort définitive" dans le jeu,
            if vie == 0:
                print ("GAME OVER")
                time.sleep(2)
# variable qui permet au joueur de choisir s'il veut recommencer cette variante du jeu ou s'il souhaite mettre fin au jeu
                recommencer = input ("Souhaitez vous recommencer l'histoire du clan de la terre ? (oui ou non) ")
                while recommencer not in ["oui", "non"]:
                    recommencer = input ("je n'ai pas compris, voulez vous recommencer ? ")
# condition qui permet au joueur de recommencer la variante et de réinitialiser son inventaire ou de quitter le jeu en fonction de sa réponse à la variable précédente
                if recommencer == "oui":
                    inventaire = []
                    bienvenue_terre()
                    guerrier_terre()
                    aventure_terre()
                    fin_terre()
                else:
                    exit()
# fin de la condition "if vie == 0" qui permet au joueur de revenir à un point antérieur dans la variante
            else:
                print ("--------------------------------------")
                print ("Vous revenez au choix de l'arme")
                print ("--------------------------------------")
                time.sleep(4)
                guerrier_terre()
                aventure_terre()
                fin_terre() 
        
                
                        
# appelle les sous-fonctions dans la fonction initiale
    bienvenue_terre ()
    guerrier_terre ()
    aventure_terre ()
    fin_terre ()

# (les 3 autres variantes sont constituées du même code que celle-ci,(à la différence de quelques détails pour que la variante fasse sens et qie l'histoire ne soit pas trop redondante) donc ne m'en voulez pas mais je ne vais pas réecrire l'entièreté du commentaire)

# --------------------------------------------------------------------------------    

def air ():
    global vie
    global inventaire
    def bienvenue_air ():
        time.sleep(2)
        print ("Vous rejoignez le clan de lair, recevez pèlerine de nuages pour votre intégration au clan.")
        time.sleep(1.5)
        inventaire.append ("pèlerine de nuages")
        time.sleep(1)
        print (inventaire)
        time.sleep(2)
        print ("Homme inconnu: 'Bonjour voyageur je suis Aerion, régent du clan de l'air. Déploie ta pèlerine et volons vers tes quartiers.'")
        time.sleep(2)
       

        print ("'Bien",prenom,"bienvenue dans la cité des nuages du clan de l'air.'")
        time.sleep(1)
        Image.open('cité_air.jpg').show()  
        time.sleep(6)
   
        
        print ("'nous fonctionnons sous 3 classes: les faiseurs d'éclairs, que tu vois sur les nuages d'orage, les tempêtes, qui volent a tout va dans toute la cité et les chevaliers de pluie.'")
        time.sleep(5)
   
    def chevalier_air ():
        print ("'Tu ferais un bon chevalier à mon goût. Tu feras tes preuves en compagnie du commandant Cirrus.'")
        time.sleep(3)
        print ("'Maintenant suis moi dans l'armurerie, il te faut une arme.'")
        time.sleep(2)
        Image.open('armurerie_air.jpg').show()
        time.sleep(6)
        print ("'Tu as le choix entre une une massue de cumulonimbus, une épée d'éclairs et un lasso de pluie de lumière.'")
        time.sleep(2)
        Image.open('armes_air.jpg').show()
        time.sleep(6)
        arme = input ("quelle arme choisis-tu ? (massue, épée, lasso) ")
        while arme not in ["massue", "épée", "lasso"]:
            arme = input ("cette arme ne fais pas partie des choix. choisis une arme: ")
        if arme == ("massue"):
            inventaire.append ("massue")
        elif arme == ("épée"):
            inventaire.append ("épée")
        elif arme == ("lasso"):
            inventaire.append ("lasso")
        time.sleep(2)
        print (inventaire)
   
    def aventure_air ():
        print ("Aerion: 'je vous laisse maintenant avec le commandant Cirrus'")
        time.sleep(2)
        print ("Commandant Cirrus: 'suis moi",prenom,"nous partons protégér la valée des nuages'")
        time.sleep(2)
        Image.open('valée des nuages.jpg').show()
        time.sleep(5)
       
        print ("Sur le chemin vous rencontrez un pégase éclair très agressif")
        time.sleep(2)
        print ("Il menace de terroriser les habitants de la cité et se dirige droit sur elle !!!")
        time.sleep(2)
        Image.open('pégase_air.jpg').show()
        time.sleep(5)
        print ("Vite",prenom,"il faut agir!")
        time.sleep(2)
        print ("Vous vous saisissez de votre arme et attaquez le pégase.")
        time.sleep(2)
   
    def fin_air ():
        global inventaire
        if "lasso" in inventaire:
            print ("Vous lancez votre lasso en direction de la tête du pégase. La corde se noue autour du cou de l'animal. vous lavez maîtrisé. Vous venez de sauver la cité!")
            time.sleep(2)
            print ("Le Commandant Cirrus vous félicite et vous ramène à la cité ou vous rejoignez Aerion.")
            time.sleep(4)
            print ("Aerion: '",prenom,"! Vous avez sauvé la valée et la cité! Vous avez passé le test des chevaliers. Vous faites officielement partie du clan de l'air. Vous pouvez vivre une vie heureuse sur Élémenterra'")
            time.sleep(5)
            exit()
        else:
            global vie
            print ("Mauvaise pioche! Vous avez énervé le pégase et qui vous lance un éclair mortel! -1 vie!")
            time.sleep(3)
            vie=vie-1
            print ("il vous reste",vie,"vie(s)")
            time.sleep(2)
            if vie == 0:
                print ("GAME OVER")
                time.sleep(2)
                recommencer = input ("Souhaitez vous recommencer l'histoire du clan de l'air ? (oui ou non) ")
                while recommencer not in ["oui", "non"]:
                    recommencer = input ("je n'ai pas compris, voulez vous recommencer ? ")
                if recommencer == "oui":
                    inventaire = []
                    bienvenue_air()
                    chevalier_air()
                    aventure_air()
                    fin_air()
                else:
                    exit()
            else:
                print ("--------------------------------------")
                print ("Vous revenez au choix de l'arme")
                print ("--------------------------------------")
                time.sleep(4)
                chevalier_air()
                aventure_air()
                fin_air() 
        
                
                        
    
    bienvenue_air ()
    chevalier_air ()
    aventure_air ()
    fin_air ()
    
   
# ---------------------------------------------------------------------------------------------------------------    
      
def eau ():
    global vie
    global inventaire
    
    def bienvenue_eau():
        time.sleep(2)
        print ("Vous rejoignez le clan de l'eau, recevez ce collier en écailles de dragon d'eau pour votre intégrtion au clan.")
        time.sleep(1.5)
        inventaire.append ("collier en écailles de dragon")
        time.sleep(1)
        print (inventaire)
        time.sleep(2)
        print ("Homme inconnu: 'Bonjour voyageur je suis Nereus, régent du clan de l'eau. Suis moi pour découvrir tes quartiers.'")
        time.sleep(2)


        print ("'Bien",prenom,"bienvenue dans le récif du clan de l'eau.'")
        time.sleep(1)
        Image.open('cité_eau.jpg').show()  
        time.sleep(6)
   
        print ("'Ici nous vivons en harmonie avec le monde marin, il nous prodigue tout ce dont nous avons besoin.'")
        time.sleep(4)
        print ("'nous fonctionnons sous 3 classes: les politiciens, qui sont dans le palais, les récolteurs de gouttes sacrées, qui vagabondent à la recherche de ces gouttes qui sont notre source d'énergie et les gardiens des profondeurs.'")
        time.sleep(5)
   
    def gardien_eau ():
        print ("'selon moi tu ferais un bon gardien. Tu feras tes preuves en compagnie du commandant Kaiyo.'")
        time.sleep(3)
        print ("'Maintenant suis moi dans l'armurerie, il te faut une arme.'")
        time.sleep(2)
        Image.open('armurerie_eau.jpg').show()
        time.sleep(6)
        print ("'Tu as le choix entre un sceptre d'eau de lune, un gladius de roche marine et un hameçon d'écume.'")
        time.sleep(2)
        Image.open('armes_eau.jpg').show()
        time.sleep(6)
        arme = input ("quelle arme choisis-tu ? (sceptre, gladius, hameçon) ")
        while arme not in ["sceptre", "gladius", "hameçon"]:
            arme = input ("cette arme ne fais pas partie des choix. choisis une arme: ")
        if arme == ("sceptre"):
            inventaire.append ("sceptre")
        elif arme == ("gladius"):
            inventaire.append ("gladius")
        elif arme == ("hameçon"):
            inventaire.append ("hameçon")
        time.sleep(2)
        print (inventaire)
   
    def aventure_eau ():
        print ("Nereus: 'je vous laisse maintenant avec le commandant Kaiyo'")
        time.sleep(2)
        print ("Commandant Kaiyo: 'suis moi",prenom,"nous partons protégér le mont des perles d'eau'")
        time.sleep(2)
        Image.open('mont des perles eau.jpg').show()
        time.sleep(5)
       
        print ("Sur le chemin vous rencontrez un dragon d'eau très agressif")
        time.sleep(2)
        print ("Il menace de dévaster le mont et se dirige droit vers le récif du clan de l'eau !!!")
        time.sleep(2)
        Image.open('dragon_eau.jpg').show()
        time.sleep(5)
        print ("Vite",prenom,"il faut agir!")
        time.sleep(2)
        print ("Vous vous saisissez de votre arme et attaquez le dragon.")
        time.sleep(2)
   
    def fin_eau ():
        global inventaire
        if "hameçon" in inventaire:
            print ("Vous vous élançez vers le dragon, votre hameçon à la main. Losque vous êtes assez rapproché vous tranchez la tête du dragon. Il s'effondre au sol. Vous avez sauvé le mont et le récif !!!")
            time.sleep(2)
            print ("Le Commandant Kaiyo vous félicite et vous ramène au récif ou vous rejoignez Nereus.")
            time.sleep(4)
            print ("Nereus: '",prenom,"! Vous avez sauvé le mont et le récif! Vous avez passé le test des gardiens. Vous faites officielement partie du clan de l'eau. Vous pouvez vivre une vie heureuse sur Élémenterra.'")
            time.sleep(6.5)
            exit()
        else:
            global vie
            print ("Mauvaise pioche! Vous avez énervé le dragon et il vous a dévoré! -1 vie!")
            time.sleep(3)
            vie=vie-1
            print ("il vous reste",vie,"vie(s)")
            time.sleep(2)
            if vie == 0:
                print ("GAME OVER")
                time.sleep(2)
                recommencer = input ("Souhaitez vous recommencer l'histoire du clan de l'eau ? (oui ou non) ")
                while recommencer not in ["oui", "non"]:
                    recommencer = input ("je n'ai pas compris, voulez vous recommencer ? ")
                if recommencer == "oui":
                    inventaire = []
                    bienvenue_eau()
                    gardien_eau()
                    aventure_eau()
                    fin_eau()
                else:
                    exit()
            else:
                print ("--------------------------------------")
                print ("Vous revenez au choix de l'arme")
                print ("--------------------------------------")
                time.sleep(4)
                gardien_eau()
                aventure_eau()
                fin_eau() 
        
                
                        
    
    bienvenue_eau ()
    gardien_eau ()
    aventure_eau ()
    fin_eau ()
 
 
# -------------------------------------------------------------------------------------------

def feu ():
    global vie
    global inventaire
    
    def bienvenue_feu():
        time.sleep(2)
        print ("Vous rejoignez le clan du feu, recevez cette chevalière enflammée pour votre intégrtion au clan.")
        time.sleep(1.5)
        inventaire.append ("chevalière enflammée")
        time.sleep(1)
        print (inventaire)
        time.sleep(2)
        print ("Femme inconnue: 'Bonjour voyageur je suis Ignatia, régente du clan du feu. Suis moi pour découvrir tes quartiers.'")
        time.sleep(2)
        
        print ("'Bien",prenom,"bienvenue dans le volcan du clan du feu.'")
        time.sleep(1)
        Image.open('volcan_feu.jpg').show()  
        time.sleep(6)
   
        print ("'Ici nous vivons en harmonie avec les flammes, elles nous prodiguent tout ce dont nous avons besoin.'")
        time.sleep(4)
        print ("'nous fonctionnons sous 3 classes: les faiseurs de lumière, qui attisent les flammes illuminant la ville, les danseurs enflammés, qui divertissent notre peuple et les destructeurs d'ombre.'")
        time.sleep(5)
   
    def destructeur_feu ():
        print ("'selon moi tu trouvera ta place parmi les destructeurs. Tu feras tes preuves en compagnie du commandant Blaze.'")
        time.sleep(3)
        print ("'Maintenant suis moi dans l'armurerie, il te faut une arme.'")
        time.sleep(2)
        Image.open('armurerie_feu.jpg').show()
        time.sleep(6)
        print ("'Tu as le choix entre une torche de flamme dévastatrice, un trident de feu et un javelot de crystal volcanique en fusion.'")
        time.sleep(2)
        Image.open('armes_feu.jpg').show()
        time.sleep(6)
        arme = input ("quelle arme choisis-tu ? (torche, trident, javelot) ")
        while arme not in ["torche", "trident", "javelot"]:
            arme = input ("cette arme ne fais pas partie des choix. choisis une arme: ")
        if arme == ("torche"):
            inventaire.append ("torche")
        elif arme == ("trident"):
            inventaire.append ("trident")
        elif arme == ("javelot"):
            inventaire.append ("javelot")
        time.sleep(2)
        print (inventaire)
   
    def aventure_feu ():
        print ("Ignatia: 'je vous laisse maintenant avec le commandant Blaze'")
        time.sleep(2)
        print ("Commandant Blaze: 'suis moi",prenom,"nous partons veiller sur le cratère du volcan'")
        time.sleep(2)
        Image.open('cratère_feu.jpg').show()
        time.sleep(5)
       
        print ("Sur le chemin vous rencontrez un phénix sombre très agressif")
        time.sleep(2)
        print ("Il menace de dévaster le volcan et se dirige droit vers la ville du clan du feu !!!")
        time.sleep(2)
        Image.open('phénix_feu.jpg').show()
        time.sleep(5)
        print ("Vite",prenom,"il faut agir!")
        time.sleep(2)
        print ("Vous vous saisissez de votre arme et attaquez le phénix.")
        time.sleep(2)
   
    def fin_feu ():
        global inventaire
        if "torche" in inventaire:
            print ("Vous approchez doucement du phénix et tendez votre torche dans sa direction. Aussitôt une lueur magique en jaillit et part illuminer le coeur du phénix qui avait autrefois perdu sa lueur. Le phénix prend son envol avec une promesse silecieuse de laisser le volcan en paix.")
            time.sleep(6.5)
            print ("Le Commandant Blaze vous félicite et vous ramène à la ville ou vous rejoignez Ignatia.")
            time.sleep(4)
            print ("Ignatia: '",prenom,"! Vous avez sauvé le volcan et notre cité! Vous avez passé le test des destructeurs. Vous faites officielement partie du clan du feu. Vous pouvez vivre une vie heureuse sur Élémenterra.'")
            time.sleep(6.5)
            exit()
        else:
            global vie
            print ("Mauvaise pioche! Vous avez énervé le phénix qui vous lacère la gorge avec ses griffes! -1 vie!")
            time.sleep(3)
            vie=vie-1
            print ("il vous reste",vie,"vie(s)")
            time.sleep(2)
            if vie == 0:
                print ("GAME OVER")
                time.sleep(2)
                recommencer = input ("Souhaitez vous recommencer l'histoire du clan du feu ? (oui ou non) ")
                while recommencer not in ["oui", "non"]:
                    recommencer = input ("je n'ai pas compris, voulez vous recommencer ? ")
                if recommencer == "oui":
                    inventaire = []
                    bienvenue_feu()
                    destructeur_feu()
                    aventure_feu()
                    fin_feu()
                else:
                    exit()
            else:
                print ("--------------------------------------")
                print ("Vous revenez au choix de l'arme")
                print ("--------------------------------------")
                time.sleep(4)
                destructeur_feu()
                aventure_feu()
                fin_feu() 
        
                
                        
    
    bienvenue_feu ()
    destructeur_feu ()
    aventure_feu ()
    fin_feu ()
    

# -----------------------------------------------------------------------------------------------------------------------------

# Texte de contextualisation de l'histoire
print ("Nous sommes en 2158, vous étiez à bord de la navette B614 qui se rendait sur l'astéroïde A359")
time.sleep(2)
print ("Durant votre voyage vous vous êtes crashé sur une planète inconnue")
time.sleep(2)
print ("Les habitants décident de vous soigner et de vous faire membre de leur communauté")
time.sleep(2)
print ("Après vous avoir soigné, ils vous amènent à la cérémonie du choix")
time.sleep(2)
print ("Le maître de cérémonie: 'Voyageur, bienvenue à Élémenterra, durant cette cérémonie vous serez amené a choisir l'élément auquel vous serez lié à jamais.'")
time.sleep(2)
# variable qui permet au joueur de choisir la variante dans laquelle se déroulera sa partie
reponse = input ("quel élément choisissez vous entre la terre, l'air, l'eau et le feu ? ")
# boucle qui empêche le joueur d'entrer en réponse une variante qui ne figure pas dans la liste
while reponse not in ["la terre", "l'air", "l'eau", "le feu"]:
    reponse = input ("'Je crains de ne pas avoir compris voyageur, quel élément choisissez vous ?' ")
    
     
# conditions qui permettent d'appeler la fonction reliée à la variante choisie par le joueur plus tôt
if reponse == ("la terre"):
    terre ()
elif reponse == ("l'air"):
    air ()
elif reponse == ("l'eau"):
    eau ()
elif reponse == ("le feu"):
    feu ()
