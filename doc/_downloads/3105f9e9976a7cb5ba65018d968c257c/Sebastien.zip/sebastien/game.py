#from loader import loading #https://stackoverflow.com/questions/34913078/importing-and-changing-variables-from-another-file
from pgzero.keyboard import keyboard
import pgzrun
import math
from random import randint
import numpy
import random
import sys

from pgzhelper import *

if len(sys.argv) > 1: #permet de lancer le jeu avec le loader ou sans sans faire crash
    general = [int(sys.argv[1]), int(sys.argv[2])]
else:
    general = [800, randint(1, 100000000)]

windowSize = [general[0], math.floor(general[0]*3/4)]

TITLE = 'goofy skeleton'


WIDTH = windowSize[0]
HEIGHT = windowSize[1]

if general[1] == 0:
    seed = randint(1, 100000000)
else:
    seed = general[1]

#son (doc https://www.pygame.org/docs/)
pygame.mixer.init()
soundEat = pygame.mixer.Sound('apple.mp3')
soundEat.set_volume(0.4)
soundFoot = pygame.mixer.Sound('footstep.mp3')
soundFoot.set_volume(0.2)
soundHit = pygame.mixer.Sound('hit.mp3')
soundHit.set_volume(0.4)
soundSlime = pygame.mixer.Sound('slimehit.mp3')
soundSlime.set_volume(0.4)
soundCactus = pygame.mixer.Sound('cactushit.mp3')
unseath = pygame.mixer.Sound('unseath.mp3')
unseath.set_volume(0.5)
win = pygame.mixer.Sound('win.mp3')
lose = pygame.mixer.Sound('lose.mp3')

pygame.mixer.music.load('music.ogg')
pygame.mixer.music.play(-1)


#systeme de generation de la map et des salles
class Salle:
    def __init__(self, xpos, ypos, id, seed, difficulty, color):
        self.portalCree = True
        self.xpos = xpos
        self.ypos = ypos
        self.id = id
        self.seedSalle = seed + id
        self.color = color
        self.difficulty = difficulty #souvent le nombre d'enemi par salle
        self.vide = True
        self.porteWest = True
        self.porteEast = True
        self.porteNord = True
        self.porteSouth = True
        if xpos == 0:
            self.porteWest = False
        if xpos == int(math.sqrt(map.size))-1:
            self.porteEast = False
        if ypos == 0:
            self.porteNord = False
        if ypos == int(math.sqrt(map.size))-1:
            self.porteSouth = False
        self.layout = []
        
    def generationSalle(self):
        salle = []
        rowVide = []
        for j in range(6):
            rowVide.append(0)
        for i in range(3):
            salle.append(rowVide)

        salle = numpy.array(salle)

        for i in range(self.difficulty):
            random.seed(int(self.seedSalle + i))
            salle[randint(0, 2), randint(0, 5)] = 1

        self.layout = salle
    
listColor = [(255, 173, 173), (255, 214, 165), (253, 255, 182), (202, 255, 191), (155, 246, 255) ,(160, 196, 255), (189, 178, 255), (255, 198, 255)]

def creationMapSalleList(map):
    salleList = []
    for i in numpy.nditer(map):
        if i not in [1, 2]:
            rows, cols = numpy.where(map == i)
            salle = Salle(cols, rows, i, seed, difficulty, listColor[i%8])
            salle.vide = False
            salle.generationSalle()     
        else:
            rows, cols = numpy.where(map == i)
            salle = Salle(cols, rows, i, seed, 0, (255, 255, 255))
            layout = []
            if salle.id == 1:
                salle.vide = True
            elif salle.id == 2:
                salle.vide = False
            listeVide = []
            for j in range(6):
                listeVide.append(0)
            for i in range(3):
                layout.append(listeVide)

            layout = numpy.array(layout)
            salle.layout = layout

        salleList.append(salle)
        
            

    return salleList

def creationMapTotal(seed, taille):
    if(taille % 2 == 0):
        return 0
    map = []
    for i in range(taille):
        listeVide = []
        for j in range(taille):
            listeVide.append(0)
        map.append(listeVide)

    map = numpy.array(map)
    map[int((taille-1)/2), int((taille-1)/2)] = 1

    endPos = int((taille-1)/2)*(taille + 1) + 1
    while endPos == int((taille-1)/2)*(taille + 1) + 1:
        random.seed(seed)
        endPos = randint(1, taille**2)
    yEndPos = (endPos-1)%taille
    xEndPos = math.floor((endPos-1)/taille)
    map[xEndPos, yEndPos] = 2

    for i in range(1, taille**2):
        idy = (i - 1) % taille
        idx = math.floor((i - 1) / taille)
        if map[idx, idy] not in [1, 2]:
            map[idx, idy] = i + 2

    return map

#actors et class utiles (aussi certaine fonction)

class Vector():
    def __init__(self, xcomp, ycomp):
        self.xcomp = xcomp
        self.ycomp = ycomp

    def size(self):
        return(pow(self.xcomp**2 + self.ycomp**2 ,0.5))
    
class Portal(Actor):
    def __init__(self, image, pos, goto, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ['portal01', 'portal02' ,'portal03' ,'portal04', 'portal05' ,'portal06']
        self.cycleAnimation = 0
        self.goto = goto

    def animation(self):
        self.cycleAnimation = (self.cycleAnimation + 0.125) % 6
        self.image = self.images[math.floor(self.cycleAnimation) % 6]

class Slash(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

        self.anime = ['slash01', 'slash02', 'slash03', 'slash04', 'slash05', 'slash06', 'slash07']
        self.cycleAnmimation = 0

    def update(self):
        orientation = ['south', 'east', 'north', 'west']
        rotation = orientation.index(player.directionPlayer)

        self.angle = rotation * 90

        self.pos = player.pos

        if player.isSlashing:
                self.image = self.anime[math.floor(self.cycleAnmimation)]
                self.cycleAnmimation += 0.5
                if self.cycleAnmimation >= 6:
                    player.isSlashing = False
                    self.cycleAnmimation = 0 
                    self.to_remove = True
        for enemy in enemiesList:
            if self.collides_with(enemy):
                enemy.to_remove = True
                if enemy.type == "bat":
                    soundSlime.play()
                else:
                    soundCactus.play()

class Vie(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        
        self.images = ['vie01', 'vie02', 'vie03', 'vie04', 'vie05', 'vie06', 'vie07']

    def updateState(self):
        self.image = self.images[int(player.life*2)]
        if player.life <= 0:
            gameOver()

class EnemyCactus(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.type = "cactus"
        self.images = ['cactus01', 'cactus02']

    def attackPlayer(self):
        if self.collides_with(player) and player.invincible == 0:
            player.invincible = 120
            player.life -= 0.5
            soundHit.play()
        

class EnemyBat(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.type = "bat"
        self.readyToAttack = 3
        self.images = ['slime00', 'slime01' ,'slime02' ,'slime03' ,'slime04', 'slime05', 'slime06' ,'slime07' ,'slime08' ,'slime09', 'slime10']
        self.circle_collidepoint

    def attackPlayer(self):
        if self.distance_to(player) >= 10:
            self.move_towards(player, int(math.floor(4*WIDTH/800)))

        if self.collides_with(player) and player.invincible == 0:
            player.invincible = 120
            player.life -= 0.5
            soundHit.play()

def createEnemies(salle):
    disposition = [
        ((int(math.floor(60*WIDTH/800))), (int(math.floor(60*HEIGHT/600)))) ,((int(math.floor(196*WIDTH/800))), (int(math.floor(60*HEIGHT/600)))), ((int(math.floor(322*WIDTH/800))), (int(math.floor(60*HEIGHT/600)))), ((int(math.floor(468*WIDTH/800))), (int(math.floor(60*HEIGHT/600)))), ((int(math.floor(604*WIDTH/800))), (int(math.floor(60*HEIGHT/600)))), ((int(math.floor(740*WIDTH/800))), (int(math.floor(60*HEIGHT/600)))),
        ((int(math.floor(60*WIDTH/800))), (int(math.floor(300*HEIGHT/600)))) ,((int(math.floor(196*WIDTH/800))), (int(math.floor(300*HEIGHT/600)))), ((int(math.floor(322*WIDTH/800))), (int(math.floor(300*HEIGHT/600)))), ((int(math.floor(468*WIDTH/800))), (int(math.floor(300*HEIGHT/600)))), ((int(math.floor(604*WIDTH/800))), (int(math.floor(300*HEIGHT/600)))), ((int(math.floor(740*WIDTH/800))), (int(math.floor(300*HEIGHT/600)))),
        ((int(math.floor(60*WIDTH/800))), (int(math.floor(540*HEIGHT/600)))) ,((int(math.floor(196*WIDTH/800))), (int(math.floor(540*HEIGHT/600)))), ((int(math.floor(322*WIDTH/800))), (int(math.floor(540*HEIGHT/600)))), ((int(math.floor(468*WIDTH/800))), (int(math.floor(540*HEIGHT/600)))), ((int(math.floor(604*WIDTH/800))), (int(math.floor(540*HEIGHT/600)))), ((int(math.floor(740*WIDTH/800))), (int(math.floor(540*HEIGHT/600))))
    ]
    k = 0
    for i in numpy.nditer(salle.layout):
        if i == 1 and k % 2 == 0:
            enemmy = EnemyBat('placeholder01', disposition[k])
            enemmy.scale = 4*WIDTH/800
            enemiesList.append(enemmy)
        if i == 1 and k % 2 == 1:
            enemmy = EnemyCactus('placeholder01', disposition[k])
            enemmy.scale = 5*WIDTH/800
            enemiesList.append(enemmy)
        
        k += 1
        

class Item(Actor):
    def __init__(self, image, pos, typeFruit, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.typeFruit = typeFruit
        if typeFruit == 1:
            self.images = ['apple00', 'apple01', 'apple02', 'apple03', 'apple04', 'apple05', 'apple06', 'apple07']
        if typeFruit == 2:
            self.images = ['negative01', 'negative02', 'negative03', 'negative04', 'negative05', 'negative06', 'negative07', 'negative08']
        if typeFruit == 3:
            self.images = ['cake']


    def consommation(self):
        if self.collides_with(player) and keyboard.e:
            soundEat.play()
            if self.typeFruit == 1 and player.life != 3:
                player.life += 0.5
            if self.typeFruit == 2:
                player.tailleSlash += 0.2
            if self.typeFruit == 3:
                gameOver()

            self.to_remove = True

            player.salleActuelle.vide = True
            player.salleActuelle.layout = salles[40].layout

            exceptionPorte = []
            if not(player.salleActuelle.porteWest):
                exceptionPorte.append("west")
            if not(player.salleActuelle.porteNord):
                exceptionPorte.append("north")
            if not(player.salleActuelle.porteEast):
                exceptionPorte.append("east")
            if not(player.salleActuelle.porteSouth):
                exceptionPorte.append("south")
            creationPortals(exceptionPorte)
            player.salleActuelle.portalCree = True

class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.velocity = Vector(0, 0)
        self.isSlashing = False
        self.xposMap = 4
        self.yposMap = 4
        self.isIdle = True
        self.directionPlayer = 'south'
        self.cycleAnimation = 0
        self.invincible = 0
        self.tailleSlash = 1
        self.life = 3
        self.canAttack = 20
        self.salleActuelle = salles[40]
        self.makeSound = 0

    def updateState(self):
        if self.invincible > 0:
            self.invincible -= 1 

        if self.canAttack > 0:
            self.canAttack -= 1

        if self.makeSound > 0:
            self.makeSound -= 1
        
    def deplacement(self):
        if keyboard.p:
            global gameState
            gameState = "gameOverWin"
        if keyboard.k and not(self.isSlashing) and self.canAttack == 0:
            unseath.play()
            self.canAttack = 20
            self.isSlashing = True
            slashActor = Slash('slash01', self.pos)
            slashActor.scale = 1.2 * player.tailleSlash * WIDTH/800
            slash.append(slashActor)
        if keyboard.w:
            if self.velocity.ycomp >= -10:
                self.velocity.ycomp -= 0.5
        if keyboard.s:
            if self.velocity.ycomp <= 10:
                self.velocity.ycomp += 0.5
        if keyboard.a:
            if self.velocity.xcomp >= -10:
                self.velocity.xcomp -= 0.5
        if keyboard.d:
            if self.velocity.xcomp <= 10:
                self.velocity.xcomp += 0.5
        if not(keyboard.w or keyboard.a or keyboard.s or keyboard.d) and self.velocity.size() >= 0:
            if self.velocity.xcomp > 1:
                self.velocity.xcomp -= 1
            elif self.velocity.xcomp <= 1 and self.velocity.xcomp > 0:
                self.velocity.xcomp = 0
            if self.velocity.xcomp < -1:
                self.velocity.xcomp += 1
            elif self.velocity.xcomp >= -1 and self.velocity.xcomp < 0:
                self.velocity.xcomp = 0
            if self.velocity.ycomp > 1:
                self.velocity.ycomp -= 1
            elif self.velocity.ycomp <= 1 and self.velocity.ycomp > 0:
                self.velocity.ycomp = 0
            if self.velocity.ycomp < -1:
                self.velocity.ycomp += 1
            elif self.velocity.ycomp >= -1 and self.velocity.ycomp < 0:
                self.velocity.ycomp = 0
                

        if self.y < int(math.floor(10 * HEIGHT/800)) and self.velocity.ycomp < 0:
            self.velocity.ycomp = 0 
        if self.y > int(math.floor(590 * HEIGHT/600)) and self.velocity.ycomp > 0:
            self.velocity.ycomp = 0 
        if self.x < int(math.floor(10 * WIDTH/800)) and self.velocity.xcomp < 0:
            self.velocity.xcomp = 0 
        if self.x > int(math.floor(790 * (WIDTH/800))) and self.velocity.xcomp > 0:
            self.velocity.xcomp = 0 

        self.x += int(math.floor(self.velocity.xcomp * (WIDTH/800)))
        self.y += int(math.floor(self.velocity.ycomp * (WIDTH/800)))

        if math.sqrt(self.velocity.xcomp ** 2 + self.velocity.ycomp ** 2) > 0 and self.makeSound == 0:
            self.makeSound = 30
            soundFoot.play()

        
    def directionName(self):
        if self.velocity.size() == 0:
            self.isIdle = True
        else:
            self.isIdle = False
            if self.velocity.ycomp != 0:
                if self.velocity.ycomp < 0:
                    self.directionPlayer = 'north'
                else:
                    self.directionPlayer = 'south'
            elif self.velocity.xcomp != 0:
                if self.velocity.xcomp < 0:
                    self.directionPlayer = 'west'
                else:
                    self.directionPlayer = 'east'

    def animationPlayer(self):
        back = ['back01', 'back02', 'back03', 'back04']
        front = ['front01', 'front02', 'front03', 'front04']
        side = ['side01', 'side02', 'side03', 'side04']
        backWalk = ['backwalk01', 'backwalk02', 'backwalk03', 'backwalk04']
        frontWalk = ['frontwalk01', 'frontwalk02', 'frontwalk03', 'frontwalk04']
        sideWalk = ['sidewalk01', 'sidewalk02', 'sidewalk03', 'sidewalk04']
        self.cycleAnimation = (self.cycleAnimation + 0.125) % 4
        if self.cycleAnimation % 1 == 0:
            if self.directionPlayer == 'south':
                if self.isIdle:
                    self.image = front[math.floor(self.cycleAnimation) % 4]
                else:
                    self.image = frontWalk[math.floor(self.cycleAnimation) % 4]
            if self.directionPlayer == 'north':
                if self.isIdle:
                    self.image = back[math.floor(self.cycleAnimation) % 4]
                else:
                    self.image = backWalk[math.floor(self.cycleAnimation) % 4]
            if self.directionPlayer == 'east':
                self.flip_x = False
                if self.isIdle:
                    self.image = side[math.floor(self.cycleAnimation) % 4] 
                else:
                    self.image = sideWalk[math.floor(self.cycleAnimation) % 4]
            if self.directionPlayer == 'west':
                self.flip_x = True
                if self.isIdle:
                    self.image = side[math.floor(self.cycleAnimation) % 4]
                else:
                    self.image = sideWalk[math.floor(self.cycleAnimation) % 4]

        image = self._surf
        if self.invincible > 0:
            image = self._surf.copy()
            image.set_alpha(100)
            # self.opacity = 0.4 https://pygame-zero.readthedocs.io/en/latest/builtins.html#transparency
        self._surf = image

    def changementSalle(self):
        for portal in portalList:
            if self.collides_with(portal):
                player.invincible = 20
                if portal.goto == "east":
                    self.xposMap += 1
                    self.pos = (int(math.floor(130*WIDTH/800)), HEIGHT/2)
                if portal.goto == "north":
                    self.yposMap -= 1
                    self.pos = (WIDTH/2, int(math.floor(450*HEIGHT/600)))
                if portal.goto == "west":
                    self.xposMap -= 1
                    self.pos = (int(math.floor(670 * WIDTH/800)), HEIGHT/2)
                if portal.goto == "south":
                    self.yposMap += 1
                    self.pos = (WIDTH/2, int(math.floor(130*HEIGHT/600)))


                for i in salles:
                    if i.xpos == self.xposMap and i.ypos == self.yposMap:
                        nouvelleSalle = i

                destrucionPortal()
                self.salleActuelle = nouvelleSalle
                self.salleActuelle.portalCree = False

                if self.salleActuelle.vide:
                    exceptionPorte = []
                    if not(player.salleActuelle.porteWest):
                        exceptionPorte.append("west")
                    if not(player.salleActuelle.porteNord):
                        exceptionPorte.append("north")
                    if not(player.salleActuelle.porteEast):
                        exceptionPorte.append("east")
                    if not(player.salleActuelle.porteSouth):
                        exceptionPorte.append("south")
                    creationPortals(exceptionPorte)
                    player.salleActuelle.portalCree = True

                    creationPortals(exceptionPorte)

                createEnemies(nouvelleSalle)

def gameOver():
    global gameState
    if player.life > 0:
        win.play()
        gameState = "gameOverWin"
    else:
        lose.play()
        gameState = "gameOverLose"
                


portalList = []

def destrucionPortal():
    for i in portalList:
        i.to_remove = True

    portalList.clear()

def creationPortals(exception):
    direction = ["east", "north", "west", "south"]
    pos = [(int(math.floor(760 * WIDTH/800)), HEIGHT/2), (WIDTH/2, int(math.floor(60*HEIGHT/600))), (int(math.floor(40*WIDTH/800)), HEIGHT/2), (WIDTH/2, int(math.floor(540*HEIGHT/600)))]
    for i in range(0, 4):
        portal = Portal('portal01', pos[i], direction[i])
        portal.angle += 90*i
        portal.scale = 4 *WIDTH/800
        if portal.goto not in exception:
            portalList.append(portal)


#decalaration de plusieurs variables dont gameState qui est globale

slash = []
difficulty = 5
enemiesList = []
item = []
map = creationMapTotal(seed, 9)
salles = creationMapSalleList(map)
player = Player('frontwalk02', (WIDTH/2, HEIGHT/2))
vie = Vie('vie07', ((int(math.floor(80*WIDTH/800))), (int(math.floor(40*HEIGHT/600)))))
player.scale = 4 *WIDTH/800 
vie.scale = 5 *WIDTH/800
global gameState
gameState = "active"
my_font = pygame.font.SysFont('Comic Sans MS', int(math.floor(30*WIDTH/800)))

creationPortals([])

#draw/update pour pygame
def draw():
    global gameState
    if gameState == "active":
        screen.fill(player.salleActuelle.color)
        for i in portalList:
            i.draw()
        for i in enemiesList:
            i.draw()
            i.animate()
        if len(slash) != 0:
            slash[0].draw()
        if len(item) != 0:
            item[0].draw()
            item[0].animate()
        player.draw()
        vie.draw()
    if gameState == "gameOverWin": #https://stackoverflow.com/questions/20842801/how-to-display-text-in-pygame
        screen.fill((255, 255, 255))
        text_surface = my_font.render('You win (q to quit)', False, (0, 0, 0))
        screen.blit(text_surface, (WIDTH*34/100, HEIGHT*45/100))
        seedText = my_font.render(("seed:" + str(seed)), False, (0,0,0))
        screen.blit(seedText, (WIDTH*34/100, HEIGHT*55/100))
    if gameState == "gameOverLose":
        screen.fill((0, 0, 0))
        text_surface = my_font.render('You lose (q to quit)', False, (255, 255, 255))
        screen.blit(text_surface, (WIDTH*34/100, HEIGHT*45/100))
def update():
    global gameState
    if gameState == "active":
        player.deplacement()
        player.directionName()
        player.animationPlayer()
        player.changementSalle()
        player.updateState()
        vie.updateState()
        for i in portalList:
            i.animation()
        for i in enemiesList:
            i.attackPlayer()
        if len(slash) != 0:
            slash[0].update()
        if len(item) != 0:
            item[0].consommation()

        if len(enemiesList) == 0 and not(player.salleActuelle.vide) and len(item) < 1: #creation d'item d'abord
            if player.salleActuelle.id == 2:
                typeFruit = 3
            elif player.salleActuelle.id % 2 == 1:
                typeFruit = 2
            elif player.salleActuelle.id % 2 == 0:
                typeFruit = 1
            itemToTake = Item('placeholder01', (WIDTH/2, HEIGHT/2), typeFruit)
            itemToTake.scale = 4 *WIDTH/800
            item.append(itemToTake)
            
        
        remove_actors(portalList)
        remove_actors(enemiesList)
        remove_actors(slash)
        remove_actors(item)
    if gameState == "gameOverWin":
        pygame.mixer.music.stop()
        if keyboard.q:
            pygame.quit()
    if gameState == "gameOverLose":
        pygame.mixer.music.stop()
        if keyboard.q:
            pygame.quit()

pgzrun.go()