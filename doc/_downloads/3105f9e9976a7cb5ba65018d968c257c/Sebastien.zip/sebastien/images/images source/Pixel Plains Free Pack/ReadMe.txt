*** Pixel Plains (PP) - AssetPack v1.0 ***

Pixel Plains is an original idea by Jose Javier (SnowHex)

---

By acquiring this asset pack:


You can:

Use these assets in any commercial or non-commercial project.
Modify the assets as much as you like.
You must give appropriate credit , I would appreciate it :) (and I would put the games made with this pack in my profile).

You can't:

Resell, repackage, or redistribute the asset, even if modified.
Include these assets in game-making tools or code templates (without permission)​.
Use the assets in a crypto, NFT, p2e, or meta-related project.


you can send me a link to the project once it's finished and I'll anchor it in my profile, plus I'll be very grateful for it n.n

SnowHexArt@Gmail.com

---

Please rate this pack ♥!
snowhex.itch.io/pixel-plains/rate


follow me on twitter so I can notify you of new updates!
https://twitter.com/SnowHexArt