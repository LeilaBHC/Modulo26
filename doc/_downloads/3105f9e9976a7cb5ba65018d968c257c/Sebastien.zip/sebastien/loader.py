from tkinter import * #la doc vient du même endroit que mon projet de l'année passée
import subprocess

def game():
    subprocess.run(['python', 'game.py', str(width.get()), str(seed.get())]) #https://www.geeksforgeeks.org/how-to-run-another-python-script-with-arguments-in-python/

root = Tk()
root.title("loader")

width = StringVar()
width.set(800)
seed = StringVar()
seed.set(0)

#constituant du loader
label1 = Label(root, text="window's width", width=30)
label1.grid(row=0, column=0, pady=20, padx = 20, sticky=N)

tailleEntryBox = Entry(root, textvariable=width, width=30)
tailleEntryBox.grid(row=1, column=0, pady=20, padx = 20, sticky=N)

label2 = Label(root, text="seed (0 for random)", width=30)
label2.grid(row=2, column=0, pady=20, padx = 20, sticky=N)

seedEntryBox = Entry(root, textvariable=seed, width=30)
seedEntryBox.grid(row=3, column=0, pady=20, padx = 20, sticky=N)

generateButton = Button(root, text="load", command = lambda : game() ,width=30)
generateButton.grid(row=4, column=0, pady=20, padx = 20, sticky=N)

root.resizable(False, False)
root.geometry("270x300")
root.mainloop()