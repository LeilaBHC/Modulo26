  ,----..                                                    .--.--.         ,-.             ,--,                 ___                          
 /   /   \                        .--.,                     /  /    '.   ,--/ /|           ,--.'|               ,--.'|_                        
|   :     :    ,---.     ,---.  ,--.'  \                   |  :  /`. / ,--. :/ |           |  | :               |  | :,'   ,---.        ,---,  
.   |  ;. /   '   ,'\   '   ,'\ |  | /\/                   ;  |  |--`  :  : ' /            :  : '               :  : ' :  '   ,'\   ,-+-. /  | 
.   ; /--`   /   /   | /   /   |:  : :        .--,         |  :  ;_    |  '  /      ,---.  |  ' |      ,---.  .;__,'  /  /   /   | ,--.'|'   | 
;   | ;  __ .   ; ,. :.   ; ,. ::  | |-,    /_ ./|          \  \    `. '  |  :     /     \ '  | |     /     \ |  |   |  .   ; ,. :|   |  ,"' | 
|   : |.' .''   | |: :'   | |: :|  : :/| , ' , ' :           `----.   \|  |   \   /    /  ||  | :    /    /  |:__,'| :  '   | |: :|   | /  | | 
.   | '_.' :'   | .; :'   | .; :|  |  .'/___/ \: |           __ \  \  |'  : |. \ .    ' / |'  : |__ .    ' / |  '  : |__'   | .; :|   | |  | | 
'   ; : \  ||   :    ||   :    |'  : '   .  \  ' |          /  /`--'  /|  | ' \ \'   ;   /||  | '.'|'   ;   /|  |  | '.'|   :    ||   | |  |/  
'   | '/  .' \   \  /  \   \  / |  | |    \  ;   :         '--'.     / '  : |--' '   |  / |;  :    ;'   |  / |  ;  :    ;\   \  / |   | |--'   
|   :    /    `----'    `----'  |  : \     \  \  ;           `--'---'  ;  |,'    |   :    ||  ,   / |   :    |  |  ,   /  `----'  |   |/       
 \   \ .'                       |  |,'      :  \  \                    '--'       \   \  /  ---`-'   \   \  /    ---`-'           '---'        
  `---`                         `--'         \  ' ;                                `----'             `----'                                   
                                              `--`                                                                                             


--information--

-plusieurs images non utilisées sont restées dans le dossier images\images source\. L'utilité de celles-ci est de... (vous pouvez voir une certaine évolution du travail)

-Source:
https://ezgif.com/sprite-cutter (pour découper les spritesheet)

https://kamioo.itch.io/pixel-cactus?download
https://rp-bricks.itch.io/apple-rotate-sprite-sheet-and-gif
https://jennpixel.itch.io/free-cake-pack-12-icons?download
https://github.com/ZayJayPlays/Godot-Placeholder-Sprites/blob/main/Square/Square-0001.png
https://pixelnauta.itch.io/pixel-dimensional-portal-32x32?download
https://snoblin.itch.io/pixel-rpg-skeleton-free
https://frostwindz.itch.io/pixel-art-slashes
https://diogo-vernier.itch.io/pixel-art-slime
https://bit-by-bit-sound.itch.io/16-bit-starter-pack
https://pixabay.com/fr/sound-effects/
Je n'ai plus la référence du UI de la bar de vie.

-gros remerciement surtout à Snoblin qui a fait le modèle du joueur (et évidemment merci aux autres artistes)

-la documentation vient de:
https://www.w3schools.com/
https://stackoverflow.com/questions
https://www.pygame.org/docs/
https://pygame-zero.readthedocs.io/en/stable/index.html
https://github.com/community
du cours

!!aucune IA n'a été utilisé pour ce travail (ce qui inclut aussi les images, sons et musique) à ma connaissance!!

-Je tiens à citer l'inspiration du jeu qui est https://store.steampowered.com/app/113200/The_Binding_of_Isaac/ et surtout https://store.steampowered.com/app/250900/The_Binding_of_Isaac_Rebirth/ (cette version est un peu mieux pour ceux qui sont curieux).

-Les contrôles sont:

wasd: déplacements
k: attaque
q: quitter (dans l'écran titre)
e: manger une pomme (négative et gâteau aussi)

-pour lancer il est préférable de lancer le loader.py et de load le jeu à partir de là (le jeu est jouable à partir de game.py mais la seed sera de toute façon aléatoire et la fenêtre ne sera redimensionnable)

-la fenêtre force le 4:3

--Gameplay--

Il faut se déplacer à travers un système de salle générée aléatoirement, afin de trouver le gâteau. Pour ce faire, il y a des portails. Les enemies de la salle, un fois tuer donne un objet qu'il faut consommer pour regagner de la vie (pomme) et augmenter la taille de sa lame (négative).

(P.S, la seed 51 permet de gagner directement en utilisant la porte nord)