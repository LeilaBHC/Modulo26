import os
from typing import List, Union
import pygame as pg

class AnimationPath:
    def __init__(self, name: str, folder_path: str, frame_duration: float | int):
        """
        name: nom de l'animation (ex: "run")
        folder_path: chemin du dossier contenant les images de l'animation
        frame_duration: durée d'affichage de chaque frame (en secondes)
        """
        self.name = name
        self.frames = sorted(
            [
                os.path.join(folder_path, f)
                for f in os.listdir(folder_path)
                if f.endswith(".png") or f.endswith(".jpg")
            ]
        )
        self.frame_duration = frame_duration
        self.current_frame_index = 0
        self.timer = 0.0
        self.is_looping = True

    def update(self, delta_time):
        self.timer += delta_time
        if self.timer >= self.frame_duration:
            self.timer -= self.frame_duration
            self.current_frame_index += 1
            if self.current_frame_index >= len(self.frames):
                if self.is_looping:
                    self.current_frame_index = 0
                else:
                    self.current_frame_index = len(self.frames) - 1

    def get_current_frame(self):
        return self.frames[self.current_frame_index]


class AnimationSequence:
    def __init__(self, name: str, frames: list[pg.Surface], frame_duration: float | int):
        """
        name: nom de l'animation (ex: "run")
        frames: liste de surfaces déjà chargées (pg.Surface)
        frame_duration: durée d'affichage de chaque frame (en secondes)
        """
        self.name = name
        self.frames = frames
        self.frame_duration = frame_duration
        self.current_frame_index = 0
        self.timer = 0.0
        self.is_looping = True

    def update(self, delta_time):
        self.timer += delta_time/1000
        if self.timer >= self.frame_duration:
            self.timer -= self.frame_duration
            self.current_frame_index += 1
            if self.current_frame_index >= len(self.frames):
                if self.is_looping:
                    self.current_frame_index = 0
                else:
                    self.current_frame_index = len(self.frames) - 1

    def get_current_frame(self) -> pg.Surface:
        return self.frames[self.current_frame_index]

class AnimatorController:
    def __init__(self, animations: List[Union[AnimationPath, AnimationSequence]]):

        self.animations = {}
        if animations:
            for animation in animations:
                self.animations[animation.name] = animation
        self.current_animation = None

    def add_animation(self, animation):
        self.animations[animation.name] = animation

    def set_animation(self, name):
        if self.current_animation is None or self.current_animation.name != name:
            if name in self.animations:
                self.current_animation = self.animations[name]
                self.current_animation.current_frame_index = 0
                self.current_animation.timer = 0.0

    def update(self, delta_time):
        if self.current_animation:
            self.current_animation.update(delta_time)

    def get_current_frame(self):
        if self.current_animation:
            return self.current_animation.get_current_frame()
        return None
