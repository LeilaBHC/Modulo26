from config.settings import *
import pygame as pg
from typing import Literal, Union, Optional


class Frame: # la plupart du code en dessous a été généré par chatgpt
    def __init__(
        self,
        rect: Optional[Union[Rect, tuple]] = None,
        children=None,
        direction: Literal["horizontal", "vertical"] = "horizontal",
        justify_content: Literal[
            "start", "center", "end", "space-between", "space-around"
        ] = "start",
        align_items: Literal["start", "center", "end"] = "start",
        bg_color: Union[tuple, None] = None,
        padding: int = 5,
        gap: int = 5,
        border_radius: int = 0,
    ):
        self.children = children if children else []
        self.direction = direction
        self.justify_content = justify_content
        self.align_items = align_items
        self.bg_color = bg_color
        self.padding = padding
        self.gap = gap
        self.border_radius = border_radius

        if rect is None:
            self.rect = self.compute_fit_content_rect()
        else:
            self.rect = Rect(rect)

    def compute_fit_content_rect(self):
        if self.direction == "horizontal":
            total_main = sum(child.rect.width for child in self.children)
            total_main += (
                self.gap * (len(self.children) - 1) if len(self.children) > 1 else 0
            )
            cross_max = max((child.rect.height for child in self.children), default=0)
            width = total_main + 2 * self.padding
            height = cross_max + 2 * self.padding
        else:
            total_main = sum(child.rect.height for child in self.children)
            total_main += (
                self.gap * (len(self.children) - 1) if len(self.children) > 1 else 0
            )
            cross_max = max((child.rect.width for child in self.children), default=0)
            height = total_main + 2 * self.padding
            width = cross_max + 2 * self.padding

        return Rect(0, 0, width, height)
    
    def set(self, children): #ca ne marche pas pour l'instant
        self.children = children
        if self.rect.width == 0 or self.rect.height == 0:
            self.rect = self.compute_fit_content_rect()
        else:
            self.rect = self.compute_fit_content_rect()

    def add(self, child):
        self.children.append(child)
        if self.rect.width == 0 or self.rect.height == 0:
            self.rect = self.compute_fit_content_rect()

    def handle_event(self, event):
        for child in self.children:
            child.handle_event(event)

    def update(self):
        for child in self.children:
            child.update()

    def draw(self, surface):
        if self.bg_color:
            pg.draw.rect(
                surface, self.bg_color, self.rect, border_radius=self.border_radius
            )

        if self.direction == "horizontal":
            total_main = sum(child.rect.width for child in self.children)
            total_main += (
                self.gap * (len(self.children) - 1) if len(self.children) > 1 else 0
            )
            main_size = self.rect.width - 2 * self.padding
            cross_size = self.rect.height - 2 * self.padding
        else:
            total_main = sum(child.rect.height for child in self.children)
            total_main += (
                self.gap * (len(self.children) - 1) if len(self.children) > 1 else 0
            )
            main_size = self.rect.height - 2 * self.padding
            cross_size = self.rect.width - 2 * self.padding

        if self.justify_content == "start":
            start_main = self.padding
            gap = self.gap
        elif self.justify_content == "center":
            start_main = (main_size - total_main) // 2 + self.padding
            gap = self.gap
        elif self.justify_content == "end":
            start_main = main_size - total_main + self.padding
            gap = self.gap
        elif self.justify_content == "space-between" and len(self.children) > 1:
            start_main = self.padding
            gap = (main_size - total_main + self.gap * (len(self.children) - 1)) // (
                len(self.children) - 1
            )
        elif self.justify_content == "space-around" and len(self.children) > 0:
            gap = (main_size - total_main + self.gap * (len(self.children) - 1)) // (
                len(self.children)
            )
            start_main = self.padding + gap // 2
        else:
            start_main = self.padding
            gap = self.gap

        main_pos = start_main

        for child in self.children:
            if self.align_items == "start":
                cross_pos = self.padding
            elif self.align_items == "center":
                if self.direction == "horizontal":
                    cross_pos = (cross_size - child.rect.height) // 2 + self.padding
                else:
                    cross_pos = (cross_size - child.rect.width) // 2 + self.padding
            elif self.align_items == "end":
                if self.direction == "horizontal":
                    cross_pos = cross_size - child.rect.height + self.padding
                else:
                    cross_pos = cross_size - child.rect.width + self.padding
            else:
                cross_pos = self.padding

            if self.direction == "horizontal":
                child.rect.topleft = (
                    self.rect.x + main_pos + getattr(child.rect, "offset_x", 0),
                    self.rect.y + cross_pos + getattr(child.rect, "offset_y", 0),
                )
                main_pos += child.rect.width + gap
            else:
                child.rect.topleft = (
                    self.rect.x + cross_pos + getattr(child.rect, "offset_x", 0),
                    self.rect.y + main_pos + getattr(child.rect, "offset_y", 0),
                )
                main_pos += child.rect.height + gap

            child.draw(surface)
