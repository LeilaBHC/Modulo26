import math
from typing import Iterable, Callable, Union

# ---------- fonctions d'easing de base ----------
def linear(t: float) -> float:
    return t

def ease(t: float) -> float:                     # cubic standard
    return t * t * (3 - 2 * t)

def ease_in(t: float) -> float:                  # quad in
    return t * t

def ease_out(t: float) -> float:                 # quad out
    return t * (2 - t)

def ease_in_out(t: float) -> float:              # quad in‑out
    return 2*t*t if t < .5 else -1 + (4 - 2*t)*t

# ---------- nouveaux easing utilisés par les boutons ----------
def ease_out_cubic(t: float) -> float:
    """Cubic‑out : départ rapide, arrivée douce."""
    t -= 1
    return t*t*t + 1

def ease_in_out_sine(t: float) -> float:
    """Sinusoïdal in‑out très fluide (idéal oscillations)."""
    return -(math.cos(math.pi * t) - 1) / 2

def elastic(t: float, amplitude: float = .25, frequency: float = 10.0) -> float:
    """Elastic customisable (amplitude et fréquence)."""
    if t == 0 or t == 1:
        return t
    c4 = (2 * math.pi) / 3
    return math.pow(2, -10*t) * amplitude * math.sin((t*frequency - .75)*c4) + 1

# ---------- utilitaires ----------
def lerp(start, end, t: float):
    """Interpolation linéaire entre deux scalaires ou deux séquences."""
    if isinstance(start, (int, float)) and isinstance(end, (int, float)):
        return start + (end - start) * t
    if isinstance(start, (tuple, list)) and isinstance(end, (tuple, list)):
        return type(start)(lerp(s, e, t) for s, e in zip(start, end))
    raise TypeError("start/end must be numbers or same‑length tuples/lists")

Number = Union[float, Iterable[float]]

# ---------- générateur de transition ----------
def transition(
    start          : Number,
    end            : Number,
    delay          : float  = 0.0,
    duration       : float  = 1.0,
    timing_function: Callable[[float], float] = linear,
) -> iter:
    """
    Génère les valeurs interpolées frame par frame (60 FPS).
    Retourne un itérateur.
    """
    fps            = 60
    delay_steps    = int(delay    * fps)
    duration_steps = max(int(duration * fps), 1)

    # Phase délai
    for _ in range(delay_steps):
        yield start

    # Phase interpolation
    for i in range(duration_steps + 1):
        t = i / duration_steps
        yield lerp(start, end, timing_function(t))