from config.settings import *
import pygame as pg

class ImageBox:
    def __init__(self, image: pg.Surface, pos=(0, 0), scale=1.0):
        self.original_image = image
        self.image = pg.transform.scale(
            image,
            (int(image.get_width() * scale), int(image.get_height() * scale))
        )
        self.rect = Rect(self.image.get_rect(topleft=pos))

    def draw(self, surface):
        surface.blit(self.image, self.rect)