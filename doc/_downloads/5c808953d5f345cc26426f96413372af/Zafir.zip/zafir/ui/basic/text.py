from config.settings import *
import pygame as pg

class Text:
    def __init__(self, text, pos=(0, 0), font=DEFAULT_FONT, font_size=DEFAULT_FONT_SIZE, color=DEFAULT_FONT_COLOR):
        self.font = pg.font.Font(font, font_size)
        self.text = text
        self.pos = pos
        self.font_size = font_size
        self.color = color

        self._render_text()

    def _render_text(self):
        self.rendered_text = self.font.render(self.text, True, self.color)
        self.rect = Rect(self.rendered_text.get_rect(topleft=self.pos))

    def handle_event(self, event):
        pass

    def update(self):
        pass

    def draw(self, surface):
        surface.blit(self.rendered_text, self.rect)

    def set(self, new_text):
        self.text = new_text
        self._render_text()

    def set_pos(self, pos):
        self.pos = pos
        self.rect.topleft = self.pos

    def set_color(self, color):
        self.color = color
        self._render_text()