from config.settings import *
import pygame as pg


class Icon:
    def __init__(self, path, pos=(0, 0), color=DEFAULT_FONT_COLOR, size=None):
        self.original_image = pg.image.load(path).convert_alpha()
        if size:
            self.original_image = pg.transform.smoothscale(self.original_image, size)

        self.color = color
        self.image = self._colorize(self.original_image, self.color)
        self.rect = Rect(self.image.get_rect(topleft=pos))
        self.hovered = False

    def _colorize(self, image, new_color):
        colored_image = image.copy()
        colored_image.lock()
        width, height = colored_image.get_size()
        for x in range(width):
            for y in range(height):
                r, g, b, a = colored_image.get_at((x, y))
                if a != 0:
                    colored_image.set_at((x, y), (*new_color, a))
        colored_image.unlock()
        return colored_image

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def handle_event(self, event):
        if event.type == pg.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        elif event.type == pg.MOUSEBUTTONDOWN and self.hovered and event.button == 1:
            self.on_click()

    def on_click(self): ...

    def set_position(self, pos):
        self.rect.topleft = pos

    def is_hovered(self):
        return self.hovered
