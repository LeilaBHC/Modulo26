import pygame as pg


class Rect(pg.rect.Rect):
    def __init__(self, *args, offset_x=0, offset_y=0):
        if len(args) == 1 and (
            isinstance(args[0], (tuple, list)) and len(args[0]) == 4
        ):
            super().__init__(*args[0])
        else:
            super().__init__(*args)

        self.offset_x = offset_x
        self.offset_y = offset_y
