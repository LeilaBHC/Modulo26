from config.settings import *
import pygame as pg
from typing import Optional
from ui.transition import *
from itertools import chain


class Button:
    def __init__(
        self, rect, callback, child=None, bg_color=DEFAULT_BUTTON_BG, hover_color=None, delay=0
    ):  
        self.delay = delay
        self.rect = Rect(rect)
        self.base_rect = Rect(self.rect.copy())
        self.bg_color = bg_color
        self.hover_color = hover_color or tuple(min(c + 40, 255) for c in self.bg_color)

        self.callback = callback
        self.child = child
        self.pressed = False
        self.hovered = False
        self.current_color = self.bg_color

        self._left_to_right_gen: Optional[iter] = None
        self._oscillating_gen: Optional[iter] = None
        self._transition_gen: Optional[iter] = None
        self._press_anim_gen: Optional[iter] = None

        self.hover_sound = pg.mixer.Sound("assets/sound/hover-button.mp3")
        self.click_sound = pg.mixer.Sound("assets/sound/click.mp3")
        self.start_moving_left_to_right()

    def start_moving_left_to_right(self):
        self._left_to_right_gen = transition(
            start= -700,
            end=-10,
            delay=self.delay,
            duration=1,
            timing_function=elastic
        )

    def start_oscillating(self):
        forward = transition(
            start=-10,
            end=10,
            duration=1,
            timing_function=ease_in_out
        )
        backward = transition(
            start=10,
            end=-10,
            duration=1,
            timing_function=ease_in_out
        )
        self._oscillating_gen = chain(forward, backward)

    def start_transition(self, start_color, end_color, duration=0.10):
        self._transition_gen = transition(
            start=start_color,
            end=end_color,
            delay=0,
            duration=duration,
            timing_function=ease_in_out,
        )

    def start_press_anim(self, shrink=0.95, duration=0.08):
        t = duration / 2
        shrink_g = transition(1.0, shrink, 0, t, ease_in_out)
        expand_g = transition(shrink, 1.0, 0, t, ease_in_out)

        self._press_anim_gen = chain(shrink_g, expand_g)

    def update(self):
        if self._left_to_right_gen:
            try:
                self.rect.offset_x = next(self._left_to_right_gen)

            except StopIteration:

                self._left_to_right_gen = None

        if self._oscillating_gen:
            try:
                self.rect.offset_x = next(self._oscillating_gen)

            except StopIteration:
                self._oscillating_gen = None

        if self._transition_gen:
            try:
                self.current_color = tuple(int(c) for c in next(self._transition_gen))
            except StopIteration:
                self._transition_gen = None

        if self._press_anim_gen:
            try:
                factor = next(self._press_anim_gen)
                self.rect = self.base_rect.copy()
                w, h = self.rect.size
                self.rect.size = (w * factor, h * factor)
                self.rect.center = self.base_rect.center
            except StopIteration:
                self.callback()
                self._press_anim_gen = None
                self.rect = self.base_rect.copy()

        if self._oscillating_gen == None and self._left_to_right_gen == None:
            self.start_oscillating()

    def draw(self, surface):
        pg.draw.rect(surface, self.current_color, self.rect, border_radius=0)

        if self.hovered:
            pg.draw.rect(surface, COLOR_WHITE, self.rect, width=3, border_radius=0)

        if self.child:
            self.child.rect.center = self.rect.center
            self.child.draw(surface)

    def handle_event(self, event):
        if event.type == pg.MOUSEMOTION:
            was_hovered = self.hovered
            self.hovered = self.rect.collidepoint(event.pos)

            if self.hovered and not was_hovered:
                self.start_transition(self.current_color, self.hover_color)
                self.hover_sound.play()
            elif not self.hovered and was_hovered:
                self.start_transition(self.current_color, self.bg_color)

        elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            if self.hovered:
                self.pressed = True
                self.start_press_anim()
                self.click_sound.play()

        elif event.type == pg.MOUSEBUTTONUP and event.button == 1:
            self.pressed = False