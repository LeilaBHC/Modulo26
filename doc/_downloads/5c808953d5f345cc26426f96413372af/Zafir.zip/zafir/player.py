from config.settings import *
from animation import AnimatorController, AnimationSequence
import pygame as pg
import random


class Player:
    def __init__(self, app):
        self.app = app
        self.screen = self.app.screen
        self.load_sequence_animation = self.app.entity_tileset.load_sequence_animation
        self.position = PLAYER_SPAWN
        self.velocity_y = 0
        self.rotation = 0
        self.hitbox_scale = 0.6
        self.flap_cooldown = 0.1
        self.last_flap_time = -999.0

        self.flying = AnimationSequence(
            name="flying",
            frames=self.load_sequence_animation(from_pos=(6, 2), to_pos=(8, 2)),
            frame_duration=0.1,
        )

        self.animations = AnimatorController(animations=[self.flying])
        self.animations.set_animation(name="flying")
        self.sprite = self.animations.get_current_frame()
        self.flip_x = True

        self.rect = self.sprite.get_rect(topleft=self.position)

    def handle_event(self, event):
        if event.type == pg.KEYDOWN and (event.key in (pg.K_SPACE, pg.K_UP)):
            self._try_flap()

        elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            self._try_flap()

    def _try_flap(self):
        """Tente de faire battre les ailes si le cooldown est écoulé."""
        now = self.app.current_time
        if now - self.last_flap_time >= self.flap_cooldown:
            self.velocity_y = FLAPPING_POWER
            self.last_flap_time = now

            s = pg.mixer.Sound(f"assets/sound/flapping{random.randint(0,2)}.mp3")
            s.play()

    def update(self):
        self.animations.update(self.app.dt)

        x, y = self.position
        self.velocity_y += GRAVITY
        y += self.velocity_y

        ground_y = 416
        floor_y = 0
        if y >= ground_y:
            y = ground_y
            self.velocity_y = 0
        elif y <= floor_y:
            y = floor_y
            self.velocity_y = 0

        self.position = (x, y)
        self.rect = self.get_scaled_hitbox((int(x), int(y)))
        pipes = self.app.game_scene.generator.pipes
        for pipe in pipes:
            if self.rect.colliderect(pipe.top_pipe.rect) or self.rect.colliderect(
                pipe.bottom_pipe.rect
            ):
                self.app.set_scene(self.app.menu_scene)
                self.app.game_scene.generator.pipes = []
                self.position = PLAYER_SPAWN
                if self.app.score > self.app.best_score:
                    self.app.best_score = self.app.score
                self.app.speed_mult = 1
                pg.mixer.music.load("assets/sound/pipe.mp3")
                pg.mixer.music.play()

        max_rot = 45
        rotation_target = max(-max_rot, min(max_rot, self.velocity_y * 15))
        self.rotation += (rotation_target - self.rotation) * 0.1

    def render(self):
        self.sprite = self.animations.get_current_frame()
        flipped_sprite = pg.transform.flip(self.sprite, self.flip_x, False)
        rotated_sprite = pg.transform.rotate(flipped_sprite, -self.rotation)

        rect = rotated_sprite.get_rect(
            center=(int(self.position[0]), int(self.position[1]))
        )
        self.screen.blit(rotated_sprite, rect.topleft)

        self.rect = rect
        if self.app.debug_mode == True:
            pg.draw.rect(
                self.screen, (255, 0, 0), self.get_scaled_hitbox(self.position), 2
            )

    def get_scaled_hitbox(self, center_pos):
        w, h = self.sprite.get_size()
        scaled_w, scaled_h = w * self.hitbox_scale, h * self.hitbox_scale
        rect = Rect(0, 0, scaled_w, scaled_h)
        rect.center = center_pos
        return rect
