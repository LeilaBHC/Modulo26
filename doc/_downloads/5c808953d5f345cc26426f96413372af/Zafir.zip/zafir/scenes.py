from config.settings import *
from config.style import COLOR_BLUE_500, COLOR_BLUE_400, COLOR_WHITE
from ui.interactive.button import Button
from ui.layout.frame import Frame
from ui.basic.text import Text
from ui.basic.icon import Icon
from tiles import Tilemap
from player import Player
from obstacle import Generator
from game_ui import GameUI
from itertools import cycle

map_data0 = [
    [8, 9, 10, 11, 8, 9, 10, 11],
    [16, 16, 16, 16, 16, 16, 16, 16],
]
map_data1 = [
    [125, 124, 125, 125, 125, -1, 124, 124, 125, -1, 126, -1],
    [22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22],
    [
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
        122,
    ],
    [
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
        142,
    ],
]

last_map0_position = (0, WIN_RES[1] - 20 * 2 * 4)
last_map1_position = (0, 396)

class Scene:
    def __init__(self, app):
        self.app = app
        self.screen = self.app.screen
        self.name = self.__class__.__name__

        self.__default_frame = Frame(
            rect=(0, 0, WIN_RES[0], WIN_RES[1]),
            bg_color=COLOR_NEUTRAL_800,
            align_items="center",
            justify_content="center",
            children=[Text(text=f"{self.name}", color=COLOR_NEUTRAL_100)],
        )

    def init_interface(self):
        pass

    def on_change_scene(self):
        pass

    def handle_event(self, event):
        pass

    def update(self):
        self.__default_frame.update()

    def render(self):
        self.__default_frame.draw(self.screen)


class LoadingScene(Scene):
    DURATION = 3.0 * 1000
    STEP_INTERVAL = 0.5 * 1000

    def __init__(self, app):
        super().__init__(app)

        self._dots_cycle = cycle([".", "..", "..."])
        self._time_acc = 0.0
        self._step_acc = 0.0
        self._finished = False

        self._title = Text(
            text="Pipistrello Volante", color=COLOR_NEUTRAL_100, font_size=28
        )
        self._status = Text(text="Loading...", color=COLOR_NEUTRAL_100, font_size=16)

        self.frame1 = Frame(
            rect=(0, 0, WIN_RES[0], WIN_RES[1]),
            bg_color=COLOR_NEUTRAL_800,
            align_items="center",
            justify_content="center",
            direction="vertical",
            children=[
                Frame(direction="vertical", children=[self._title, self._status])
            ],
        )

    def update(self):
        if self._finished:
            return

        self._time_acc += self.app.dt
        self._step_acc += self.app.dt

        if self._step_acc >= self.STEP_INTERVAL:
            self._step_acc -= self.STEP_INTERVAL
            self._status.set(f"Loading{next(self._dots_cycle)}")

        if self._time_acc >= self.DURATION:
            self._finished = True
            self.on_loading_complete()

        self.frame1.update()

    def render(self):
        self.frame1.draw(self.screen)

    def on_loading_complete(self):
        self.app.set_scene(self.app.menu_scene)


class MenuScene(Scene):
    def __init__(self, app):
        global last_map0_position, last_map1_position
        super().__init__(app)
        self.screen = self.app.screen

        self.tilemap0 = Tilemap(
            tileset=self.app.background_tileset,
            position=last_map0_position,
        )
        self.tilemap0.load_map(map_data0)
        self.tilemap1 = Tilemap(
            tileset=self.app.tile_tileset,
            position=last_map1_position,
        )
        self.tilemap1.load_map(map_data1)

    def init_interface(self):

        self.text1 = Text(
            text=f"Best: {self.app.best_score}",
            color=COLOR_AMBER_500,
            font_size=48,
            font=FONT_KENNEY_BLOCKS,
        )

        self.text2 = Text(
            text=f"Last: {self.app.best_score}",
            color=COLOR_AMBER_600,
            font_size=35,
            font=FONT_KENNEY_BLOCKS,
        )

        self.frame0 = Frame(
            direction="vertical",
            justify_content="center",
            align_items="center",
            gap=-15,
            children=[
                self.text2,
                self.text1
            ]
        )

        self.frame1 = Frame(
            rect=(0, 0, WIN_RES[0], WIN_RES[1]),
            direction="vertical",
            justify_content="center",
            align_items="center",
            gap=10,
            children=[
                self.frame0,
                Button(
                    rect=(0, 0, 200, 50),
                    callback=self.start_game,
                    delay=0,
                    child=Frame(
                        rect=(0, 0, 160, 50),
                        align_items="center",
                        justify_content="space-around",
                        children=[
                            Icon(path="assets/icon/solid/play.svg", size=(24, 24)),
                            Text(text="Play", font=FONT_KENNEY_BLOCKS),
                        ],
                    ),
                ),
                Button(
                    rect=(0, 0, 200, 50),
                    callback=self.stop_game,
                    delay=0.2,
                    child=Frame(
                        rect=(20, 0, 160, 50),
                        align_items="center",
                        justify_content="space-around",
                        children=[
                            Icon(
                                path="assets/icon/solid/right-from-bracket.svg",
                                size=(24, 24),
                            ),
                            Text(text="Quit", font=FONT_KENNEY_BLOCKS),
                        ],
                    ),
                ),
            ],
        )

    def on_change_scene(self):
        self.tilemap0.position = last_map0_position
        self.tilemap1.position = last_map1_position
        self.init_interface()

    def handle_event(self, event):
        self.frame1.handle_event(event)
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_SPACE:
                self.start_game()

    def update(self):
        self.frame1.update()

        self.tilemap0.scroll_x(round( -BASE_SPEED / 10, 0))
        self.tilemap1.scroll_x(round( -BASE_SPEED * self.app.speed_mult, 0))
        self.text1.set(f"Best: {self.app.best_score}")
        self.text2.set(f"Last: {self.app.score}")

        if self.tilemap0.position[0] <= -self.tilemap0.width:
            self.tilemap0.position = (0, self.tilemap0.position[1])
        if self.tilemap1.position[0] <= -self.tilemap1.width:
            self.tilemap1.position = (0, self.tilemap1.position[1])

    def render(self):
        self.tilemap0.render(self.screen)
        if self.tilemap0.position[0] + self.tilemap0.width < WIN_RES[0]:
            pos = (
                self.tilemap0.position[0] + self.tilemap0.width,
                self.tilemap0.position[1],
            )
            self.tilemap0.position = pos
            self.tilemap0.render(self.screen)
            self.tilemap0.position = (pos[0] - self.tilemap0.width, pos[1])  # reset

        self.tilemap1.render(self.screen)
        if self.tilemap1.position[0] + self.tilemap1.width < WIN_RES[0]:
            pos = (
                self.tilemap1.position[0] + self.tilemap1.width,
                self.tilemap1.position[1],
            )
            self.tilemap1.position = pos
            self.tilemap1.render(self.screen)
            self.tilemap1.position = (pos[0] - self.tilemap1.width, pos[1])  # reset

        self.frame1.draw(self.screen)

    def start_game(self):
        global last_map0_position, last_map1_position
        self.app.score = 0
        last_map0_position = self.tilemap0.position
        last_map1_position = self.tilemap1.position
        self.app.set_scene(self.app.game_scene)

    def stop_game(self):
        self.app.is_running = False

    def brainrot(self):
        pg.mixer.music.load("assets/sound/brainrot.mp3")
        pg.mixer.music.play(0)


class GameScene(Scene):
    BASE_SCROLL_BG   = BASE_SPEED / 10
    BASE_SCROLL_FG   = BASE_SPEED

    def __init__(self, app):
        super().__init__(app)

        self.tilemap_bg = Tilemap(
            tileset=self.app.background_tileset,
            position=(0, 0),
        )
        self.tilemap_bg.load_map(map_data0)

        self.tilemap_fg = Tilemap(
            tileset=self.app.tile_tileset,
            position=(0, 0),
        )
        self.tilemap_fg.load_map(map_data1)

        self.player     = Player(self.app)
        self.generator  = Generator(self.app)
        self.score_ui   = GameUI(self.app)

    def on_change_scene(self):
        global last_map0_position, last_map1_position

        self.__init__(self.app)
        self.tilemap_bg.position = last_map0_position
        self.tilemap_fg.position = last_map1_position

        pg.mixer.music.load("assets/sound/music.mp3")
        pg.mixer.music.play(-1)

    def handle_event(self, event):
        self.player.handle_event(event)

    def update(self):
        self.player.update()
        self.generator.update()

        speed_mult = self.app.speed_mult
        self.tilemap_bg.scroll_x(round( -self.BASE_SCROLL_BG * speed_mult))
        self.tilemap_fg.scroll_x(round( -self.BASE_SCROLL_FG * speed_mult))

        if self.tilemap_bg.position[0] <= -self.tilemap_bg.width:
            self.tilemap_bg.position = (0, self.tilemap_bg.position[1])

        if self.tilemap_fg.position[0] <= -self.tilemap_fg.width:
            self.tilemap_fg.position = (0, self.tilemap_fg.position[1])

        self.score_ui.update()
                
    def render(self):
        self._render_looping_map(self.tilemap_bg)
        self.generator.render()
        self._render_looping_map(self.tilemap_fg)
        self.player.render()
        self.score_ui.render()

        if self.app.debug_mode:
            for rect in self.tilemap_fg.get_collision_rects():
                pg.draw.rect(self.screen, (255, 0, 0), rect, 1)

    def _render_looping_map(self, tilemap):
        """Dessine la tilemap et son duplicata pour un scroll infini."""
        tilemap.render(self.screen)
        if tilemap.position[0] + tilemap.width < WIN_RES[0]:
            dup_pos = (tilemap.position[0] + tilemap.width, tilemap.position[1])
            tilemap.position = dup_pos
            tilemap.render(self.screen)
            tilemap.position = (dup_pos[0] - tilemap.width, dup_pos[1])