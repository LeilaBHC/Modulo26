import pygame as pg
from config.settings import *
from typing import Tuple


class Tileset:
    def __init__(self, path: str, tile_size: Tuple[int, int], scale: float = 1.0):
        self.tile_size = tile_size
        self.scale = scale
        self.scaled_tile_size = (int(tile_size[0] * scale), int(tile_size[1] * scale))

        self.image = pg.image.load(path).convert_alpha()
        self.cols = self.image.get_width() // tile_size[0]
        self.rows = self.image.get_height() // tile_size[1]
        self.tiles = self._slice_tiles()

    def _slice_tiles(self) -> list[list[pg.Surface]]:
        """Découpe les tuiles et retourne une grille 2D de surfaces"""
        grid = []
        for y in range(self.rows):
            row = []
            for x in range(self.cols):
                rect = Rect(
                    x * self.tile_size[0],
                    y * self.tile_size[1],
                    self.tile_size[0],
                    self.tile_size[1],
                )
                tile = self.image.subsurface(rect).copy()
                if self.scale != 1.0:
                    tile = pg.transform.scale(tile, self.scaled_tile_size)
                row.append(tile)
            grid.append(row)
        return grid

    def get_tile(self, pos: tuple[int, int]) -> pg.Surface:
        """Retourne la surface de la tuile (col, row)"""
        if 0 <= pos[1] < self.rows and 0 <= pos[0] < self.cols:
            return self.tiles[pos[1]][pos[0]]
        raise IndexError("Tuile en dehors du tileset")

    def get_flat_tile_list(self) -> list[pg.Surface]:
        """Retourne toutes les tuiles à plat (utilisable pour Tilemap)"""
        return [tile for row in self.tiles for tile in row]

    def load_sequence_animation(
        self, from_pos: tuple[int, int], to_pos: tuple[int, int]
    ) -> list[pg.Surface]:
        """
        Charge une séquence d'images entre from_pos (col,row) et to_pos (col,row) inclus.
        Parcours les tuiles de gauche à droite puis de haut en bas,
        ou dans l'ordre inverse si to_pos est avant from_pos.
        """
        images = []
        from_col, from_row = from_pos
        to_col, to_row = to_pos

        step_row = 1 if to_row >= from_row else -1
        step_col = 1 if to_col >= from_col else -1

        row = from_row
        while row <= to_row if step_row > 0 else row >= to_row:
            if row == from_row:
                start_col = from_col
            else:
                start_col = 0 if step_col > 0 else self.cols - 1

            if row == to_row:
                end_col = to_col
            else:
                end_col = self.cols - 1 if step_col > 0 else 0

            col = start_col
            while col <= end_col if step_col > 0 else col >= end_col:
                images.append(self.get_tile(pos=(col, row)))
                col += step_col

            row += step_row

        return images


class Tilemap:
    def __init__(self, tileset: Tileset, position: tuple[int, int] = (0, 0)):
        self.tileset = tileset
        self.tile_size = tileset.scaled_tile_size  # (w, h)
        self.position = position
        self.tiles = []
        self.tile_images = tileset.get_flat_tile_list()
        self.collision_rects: list[Rect] = []

    def load_map(self, map_data: list[list[int]]):
        self.tiles = map_data
        self.rows = len(map_data)
        self.cols = len(map_data[0]) if self.rows > 0 else 0
        self.width = self.cols * self.tile_size[0]
        self.height = self.rows * self.tile_size[1]
        self._build_collision_rects()

    def _build_collision_rects(self):
        """Crée un Rect pour chaque tuile solide (index != -1)."""
        self.collision_rects.clear()
        tw, th = self.tile_size
        for r, row in enumerate(self.tiles):
            for c, idx in enumerate(row):
                if idx != -1:
                    x = c * tw + self.position[0]
                    y = r * th + self.position[1]
                    self.collision_rects.append(Rect(x, y, tw, th))

    def get_collision_rects(self) -> list[Rect]:
        """Retourne les Rects, mis à jour avec le défilement actuel."""
        offset_x, offset_y = self.position
        tw, th = self.tile_size
        rects = []
        for r, row in enumerate(self.tiles):
            for c, idx in enumerate(row):
                if idx != -1:
                    rects.append(Rect(c * tw + offset_x, r * th + offset_y, tw, th))
        return rects

    def scroll_x(self, dx: float):
        """Fait défiler horizontalement la tilemap."""
        x, y = self.position
        self.position = (x + dx, y)

    def render(self, surface: pg.Surface):
        offset_x, offset_y = self.position
        for r, row in enumerate(self.tiles):
            for c, idx in enumerate(row):
                if 0 <= idx < len(self.tile_images):
                    x = c * self.tile_size[0] + offset_x
                    y = r * self.tile_size[1] + offset_y
                    surface.blit(self.tile_images[idx], (x, y))
