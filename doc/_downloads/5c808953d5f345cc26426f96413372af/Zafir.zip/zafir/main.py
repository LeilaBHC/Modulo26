import pygame as pg
from config.settings import *
from scenes import MenuScene, GameScene, LoadingScene
from tiles import Tileset

class App:
    def __init__(self):
        pg.init()
        self.is_running = True
        flags = pg.NOFRAME
        self.screen = pg.display.set_mode(WIN_RES, flags)
        pg.display.set_caption("Pipistrello Volante")
        self.clock = pg.time.Clock()
        self.current_scene = None
        self.current_time = 0
        self.debug_mode = DEBUG_MODE
        self.dt = 0
        self.score = 0
        self.speed_mult = 1
        self.best_score = 0

    def on_init(self):
        self.start_time = pg.time.get_ticks()

        self.entity_tileset = Tileset(path="assets/tileset/tilemap-characters_packed.png", tile_size=(24,24), scale=2.0)
        self.background_tileset = Tileset(path="assets/tileset/tilemap-backgrounds_packed.png", tile_size=(24,24), scale=2.0)
        self.tile_tileset = Tileset(path="assets/tileset/tilemap_packed.png", tile_size=(18,18), scale=2.0)

        self.loading_scene = LoadingScene(self)
        self.menu_scene = MenuScene(self)
        self.game_scene = GameScene(self)

        self.set_scene(self.loading_scene)

    def set_scene(self, scene):
        self.current_scene = scene
        self.current_scene.on_change_scene() 

    def run(self):
        self.on_init()
        while self.is_running:
            self.handle_events()
            self.update()
            self.render()
            self.dt = self.clock.tick(60)
            current_time = pg.time.get_ticks() - self.start_time
            current_time_s = current_time / 1000
            self.current_time = current_time_s
            pg.display.set_caption(f"Temps écoulé : {current_time_s:.2f}s")

    def handle_events(self):
        for event in pg.event.get():
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_d:
                    self.debug_mode = True if self.debug_mode == False else False
            
            if event.type == pg.QUIT:
                self.is_running = False
            if self.current_scene:
                self.current_scene.handle_event(event)


    def update(self):
        if self.current_scene:
            self.current_scene.update()

    def update_speed_mult(self):
        """Appelée chaque fois qu’un tuyau est passé."""
        new_value = self.speed_mult + SPEED_STEP
        new_value = min(new_value, MAX_SPEED)
        self.speed_mult = round(new_value, 2)

    def render(self):
        self.screen.fill(DEFAULT_BG)
        if self.current_scene:
            self.current_scene.render()
        pg.display.flip()

if __name__ == "__main__":
    app = App()
    app.run()
