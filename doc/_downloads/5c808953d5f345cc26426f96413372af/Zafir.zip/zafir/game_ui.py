from config.settings import *
from tiles import Tilemap
from ui.layout.frame import Frame
from ui.basic.image_box import ImageBox

class GameUI:
    def __init__(self, app):
        self.app = app
        self.screen = self.app.screen
        self.tileset = self.app.tile_tileset
        self.last_score = -1
        
        self.screen_frame = Frame(
            rect=(0, 0, WIN_RES[0], WIN_RES[1]),
            children=[],
            justify_content="start",
            align_items="start",
            gap=-15,
        )

    def update(self):
        if self.app.score != self.last_score:
            self.last_score = self.app.score
            self.update_score_tiles()

    def update_score_tiles(self):
        score_str = str(self.app.score)
        new_children = []

        for char in score_str:
            if char.isdigit():
                digit = int(char)
                tile = self.tileset.get_tile(pos=(digit, 8))
                img_box = ImageBox(tile)
                new_children.append(img_box)

        self.screen_frame.children = new_children

    def render(self):
        self.screen_frame.draw(self.screen)