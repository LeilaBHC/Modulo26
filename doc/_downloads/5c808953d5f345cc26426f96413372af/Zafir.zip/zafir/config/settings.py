from config.style import *
from ui.basic.rect import Rect

pg.mixer.init()
pg.font.init()

DEFAULT_FONT = FONT_BAHNSCHRIFT
DEFAULT_BG = (223, 246, 245)
DEFAULT_FONT_COLOR = COLOR_WHITE
DEFAULT_FONT_SIZE = 24
DEFAULT_BUTTON_BG = COLOR_EMERALD_600

PLAYER_SPAWN = (48, -24)
WIN_RES = (288, 512)
DEBUG_MODE = False

# multiplier
BASE_SPEED = 3
SPEED_STEP = 0.05  # +5 % par tuyau (ajuste à ton goût)
MAX_SPEED = 5  # limite pour ne pas devenir injouable

TILE_SIZE = 18
TILE_SCALE = 2
GRAVITY = 9.81 / 25
FLAPPING_POWER = -7
