from config.settings import *
import random
from tiles import Tilemap

map_data0 = [[95], [115], [115], [115], [115], [115], [115], [115], [115]]
map_data1 = [
    [115],
    [115],
    [115],
    [115],
    [115],
    [115],
    [115],
    [115],
    [135],
]


class Obstacle:
    def __init__(self, app, x, y, flipped=False):
        self.app = app
        self.screen = self.app.screen
        self.tileset = self.app.tile_tileset
        self.x = x
        self.y = y
        self.flipped = flipped
        self.speed = BASE_SPEED
        self.image = self.tileset.get_tile(pos=(15, 5))

        if self.flipped:
            self.tilemap = Tilemap(self.tileset, (self.x, self.y))
            self.tilemap.load_map(map_data1)
        else:
            self.tilemap = Tilemap(self.tileset, (self.x, self.y))
            self.tilemap.load_map(map_data0)

        width = self.image.get_width()
        height = self.image.get_height() * 9
        self.rect = Rect(self.x, self.y, width, height)

    def update(self):
        # vitesse dynamique
        self.x -= round(BASE_SPEED * self.app.speed_mult, 0)
        self.tilemap.position = (self.x, self.y)
        self.rect.topleft = (self.x, self.y)

    def render(self):
        self.tilemap.render(self.screen)
        if self.app.debug_mode:
            for rect in self.tilemap.get_collision_rects():
                pg.draw.rect(self.screen, (255, 0, 0), rect, 1)

    def is_off_screen(self):
        return self.x + self.image.get_width() < 0


class PipePair:
    def __init__(self, app, x, gap_y, gap_size):
        self.app = app
        self.x = round(x // (TILE_SIZE * TILE_SCALE)) * (TILE_SIZE * TILE_SCALE)
        self.y_top = int((gap_y - 300) // (TILE_SIZE * TILE_SCALE)) * (
            TILE_SIZE * TILE_SCALE
        )
        self.y_bottom = int((gap_y + gap_size) // (TILE_SIZE * TILE_SCALE)) * (
            TILE_SIZE * TILE_SCALE
        )
        self.scored = False
        self.speed = 3

        self.top_pipe = Obstacle(app, x, self.y_top, flipped=True)
        self.bottom_pipe = Obstacle(app, x, self.y_bottom, flipped=False)

    def update(self):
        speed = round(BASE_SPEED * self.app.speed_mult, 0)
        self.x -= speed

        self.top_pipe.x = self.x
        self.bottom_pipe.x = self.x

        self.top_pipe.update()
        self.bottom_pipe.update()

    def render(self):
        self.top_pipe.render()
        self.bottom_pipe.render()

    def is_off_screen(self):
        return self.bottom_pipe.is_off_screen()

    def check_score(self, player_x):
        if not self.scored and self.x + self.top_pipe.image.get_width() < player_x:
            self.scored = True
            self.app.score += 1
            self.app.update_speed_mult()


class Generator:
    def __init__(self, app):
        self.app = app
        self.pipes = []
        self.spawn_timer = 0
        self.spawn_interval = 1500

    def update(self):
        self.spawn_timer += self.app.dt
        if self.spawn_timer >= self.spawn_interval:
            self.spawn_timer = 0
            self.spawn_pair()

        for pipe_pair in self.pipes:
            pipe_pair.update()
            pipe_pair.check_score(self.app.game_scene.player.position[0])

        self.pipes = [p for p in self.pipes if not p.is_off_screen()]

    def spawn_pair(self):
        gap_size = 140
        gap_y = random.randint(100, self.app.screen.get_height() - 200)
        pair = PipePair(self.app, WIN_RES[0], gap_y, gap_size)
        self.pipes.append(pair)

    def render(self):
        for pipe_pair in self.pipes:
            pipe_pair.render()
