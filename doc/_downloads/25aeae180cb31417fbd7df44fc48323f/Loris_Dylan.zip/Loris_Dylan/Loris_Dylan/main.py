import pgzrun
from pgzhelper import *

TITLE = "Singe Souls"


WORLD_MAP = [
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,11,3,0,5,0],
    [0,0,0,0,0,0,6,8,0,0,6,7,7,8,0],
    [0,0,3,3,0,0,0,0,0,0,0,0,0,0,0],
    [0,6,7,7,8,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,6,7,7,8,0,0,0],
    [9,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [7,7,7,7,10,10,7,7,7,7,7,7,7,7,7],
]

WORLD_MAP_2 = [
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,3,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,6,7,7,8,0],
    [0,0,3,3,0,0,0,0,0,0,0,0,0,0,0],
    [0,6,7,7,8,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,3,0,3,0,0,0,0],
    [0,0,0,0,0,0,0,0,6,7,7,8,0,0,0],
    [9,0,12,0,0,0,0,0,0,0,3,0,0,0,0],
    [7,7,7,7,10,10,7,7,7,7,7,7,7,7,7],
]

WORLD_MAP_3 = [
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [9,0,0,0,0,0,0,0,0,0,0,11,0,0,0],
    [7,7,7,7,7,7,7,7,7,7,7,7,7,7,7],
]



TILE_SIZE = 100  #Taille d'un bloc en pixel
ROWS = len(WORLD_MAP) # Nombre de lignes
COLS = len(WORLD_MAP[0]) # Nombre de colonnes

WIDTH = COLS*TILE_SIZE # Largeur de la fenêtre de jeu
HEIGHT = ROWS*TILE_SIZE # Hauteur


GRAVITY = 0.5

game_over = False


class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.vy = 0
        self.speed = 10
        self.hp = 3
        self.score = 0

    def update(self):
        self.vy += GRAVITY

        if keyboard.a:
            self.x -= self.speed
            self.flip_x = False
            if self.images != ["singe_run1", "singe_run2"]: #si images pas mis à jour
                self.images = ["singe_run1", "singe_run2"]
        elif keyboard.d:
            self.x += self.speed
            self.flip_x = True
            if self.images != ["singe_run1", "singe_run2"]:
                self.images = ["singe_run1", "singe_run2"]

        else:
            self.images = ["singe_stop"]

        detector_border(self)

        if keyboard.v:
            self.speed = 20
        else:
            self.speed = 10

        for platform in platforms:
            platform.check_collision_with_actor(self)

        if keyboard.space and self.vy == 0:
            self.vy = -15

        self.y += self.vy

        for slime in slimes:
            if self.collides_with(slime):
                sounds.splat.play()
                sounds.splat.set_volume(0.1)
                slime.to_remove = True
                self.hp -= 1

        for alien in aliens:
            if self.collides_with(alien):
                sounds.splat.play()
                sounds.splat.set_volume(0.1)
                self.hp -= 1



class Banane(Actor):
    def __init__(self, image, pos, direction, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 20
        self.direction = direction
        self.vy = 0


    def update(self):
        self.vy += GRAVITY

        self.move_in_direction(self.speed)

        for slime in slimes:
            if self.collides_with(slime):
                sounds.splat.play()
                sounds.splat.set_volume(0.1)
                slime.to_remove = True
                self.to_remove = True
                player.score += 1

        for alien in aliens:
            if self.collides_with(alien):
                sounds.splat.play()
                sounds.splat.set_volume(0.1)
                alien.to_remove = True
                self.to_remove = True
                player.score += 1000


        for platform in platforms:
            if self.collides_with(platform):
                self.to_remove = True

        self.y += self.vy



class Slime(Actor):
    def __init__(self, image, pos, max_distance_x, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ["slime_green1", "slime_green2"]
        self.vy = 0
        self.speed = 1
        self.max_distance_x = max_distance_x
        self.distance_x = 0

    def update(self):
        self.vy += GRAVITY

        for platform in platforms:
          platform.check_collision_with_actor(self)

        self.x += self.speed
        self.y += self.vy
        self.distance_x += self.speed

        if not (0 <= self.distance_x <= self.max_distance_x):
            self.flip_x = not self.flip_x
            self.speed = -self.speed


class Alien(Actor):
    def __init__(self, image, pos, max_distance_x, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.vy = 0
        self.speed = 0
        distance = 10

    def update(self):
        self.vy += GRAVITY

        for platform in platforms:
          platform.check_collision_with_actor(self)

        self.y += self.vy


class Coin(Actor):
    def __init__(self, image, pos, **kwargs):
      super().__init__(image, pos, **kwargs)

    def update(self):
        if player.collides_with(self):
            player.score += 1
            self.to_remove = True
            sounds.piece.play()



class Portal(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        if player.collides_with(self) and keyboard.e:
            print('Niveau 2 !')
            global platforms
            global slimes
            global aliens
            global coins
            global portals
            global portals2
            platforms, slimes, aliens, coins, portals, portals2 = load_level(WORLD_MAP_2)

class Portal2(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        if player.collides_with(self) and keyboard.f:
            print('Niveau final !')
            global platforms
            global slimes
            global aliens
            global coins
            global portals
            global portals2
            platforms, slimes, aliens, coins, portals, portals2 = load_level(WORLD_MAP_3)


def detector_border(actor):
    if actor.x > WIDTH:
        actor.x = WIDTH
    if actor.x < 0:
        actor.x = 0
    if actor.y > HEIGHT:
        player.hp -= 1
    if actor.y < 0:
        actor.y = 0

def on_mouse_down(pos):
    if player.flip_x == True:
        direction = 0
    elif player.flip_x == False:
        direction = 180
    banane = Banane("banane", (player.x, player.y), direction, height = 50)
    bananes.append(banane)


player = Player("singe_stop", (WIDTH/2, HEIGHT/2-100), height = 100)
bananes = []

music.play("malenia")
music.set_volume(0.1)

def load_level(world_map):
    platforms = []
    slimes = []
    aliens = []
    coins = []
    portals = []
    portals2 = []
    for row in range(ROWS):
        for col in range(COLS):
            pos = (col*TILE_SIZE+TILE_SIZE/2, row*TILE_SIZE+TILE_SIZE/2)
            if world_map[row][col] == 1:
                platform = Platform('grass_tile', pos, solid = True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 2:
                platform = Platform("singe", pos, solid = True, sticky = True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 3:
                slime = Slime("slime_green1", pos, max_distance_x = 100)
                slimes.append(slime)
            elif world_map[row][col] == 4:
                coin = Coin("coin", pos, width=TILE_SIZE/2)
                coins.append(coin)
            elif world_map[row][col] == 5:
                portal = Portal("portal", pos, width=TILE_SIZE/1.5)
                portals.append(portal)
            elif world_map[row][col] == 6:
                platform = Platform("neige_gauche", pos, solid = True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 7:
                platform = Platform("neige_centre", pos, solid = True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 8:
                platform = Platform("neige_droite", pos, solid = True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 9:
                platform = Platform("neige_coing", pos, solid = True, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 10:
                platform = Platform("eau", pos, width=TILE_SIZE)
                platforms.append(platform)
            elif world_map[row][col] == 11:
                alien = Alien("alien_walk1", pos, max_distance_x = 100)
                aliens.append(alien)
            elif world_map[row][col] == 12:
                portal2 = Portal2("portal2", pos, width=TILE_SIZE/1.5)
                portals2.append(portal2)

    return platforms, slimes, aliens, coins, portals, portals2

platforms, slimes, aliens, coins, portals, portals2 = load_level(WORLD_MAP)


def draw():
    if game_over == True:
        screen.fill((0, 0, 0))
        screen.draw.text("Game Over", (WIDTH / 3, HEIGHT / 3), color = (255,0,0), fontsize = 150)
        screen.draw.text("Score : " + str(player.score), (WIDTH / 4, HEIGHT / 2), color = (255,255,255), fontsize = 100)

    elif player.score >= 2000:
        screen.fill((0, 0, 0))
        screen.draw.text("VICTORY", (WIDTH / 3, HEIGHT / 3), color = (255,0,0), fontsize = 150)
        screen.draw.text("Score : " + str(player.score), (WIDTH / 4, HEIGHT / 2), color = (255,255,255), fontsize = 100)

    else:
        screen.blit("fond_neige", (0, 0))
        screen.draw.text("Score : " + str(player.score), (10, 10), color = (255,0,0), fontsize = 30)
        screen.draw.text("Vies restantes : " + str(player.hp), (1300, 10), color = (255,0,0), fontsize = 30)
        for platform in platforms:
            platform.draw()
        player.draw()
        player.animate()
        for banane in bananes:
            banane.draw()
        for slime in slimes:
            slime.draw()
        for alien in aliens:
            alien.draw()
        for coin in coins:
            coin.draw()
        for portal in portals:
            portal.draw()
        for portal2 in portals2:
            portal2.draw()



def update():
    global game_over

    player.update()
    for banane in bananes:
        banane.update()
    for slime in slimes:
        slime.update()
    for alien in aliens:
        alien.update()
    for coin in coins:
        coin.update()
    for portal in portals:
        portal.update()
    for portal2 in portals2:
        portal2.update()
    if player.hp <= 0:
        game_over = True

    remove_actors(bananes)
    remove_actors(slimes)
    remove_actors(aliens)
    remove_actors(coins)


pgzrun.go()
