from pgzhelper import *
from random import *

TITLE = "FISH"

WIDTH = 800
HEIGHT = 600


class Player(Actor):

    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ["fishtile_080"]
        self.deplacement = True
        self.speed = 10
        self.vie = 3
        self.argent = 0
        self.endofgame = 0

    def update(self):
        self.deplacement = False
        if keyboard.a:
            self.x -= self.speed
            self.flip_x = True
            self.deplacement = True
        elif keyboard.d:
            self.x += self.speed
            self.flip_x = False
            self.deplacement = True
        if keyboard.w:
            self.y -= self.speed
            self.deplacement = True
        elif keyboard.s:
            self.y += self.speed
            self.deplacement = True
        if keyboard.e:
            self.x += self.speed
            self.y -= self.speed
            self.flip_x = False
            self.deplacement = True
        elif keyboard.y:
            self.x -= self.speed
            self.y += self.speed
            self.flip_x = True
            self.deplacement = True
        if keyboard.q:
            self.x -= self.speed
            self.y -= self.speed
            self.flip_x = True
            self.deplacement = True
        elif keyboard.x:
            self.x += self.speed
            self.y += self.speed
            self.flip_x = False
            self.deplacement = True

        if keyboard.r:
            retour_zero(self, Ennemi)

        if self.vie == 0:
            self.speed = 0
            self.flip_x = False
            self.image = "fishtile_099"
            self.endofgame = self.endofgame + 1
            if self.endofgame == 1:
                print("Game over")

        detect_border(self)


class Ennemi(Actor):

    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ["fishtile_100"]
        self.direction = randint(0, 360)
        self.speed = 2

    def update(self):
        self.direction += randint(-10, 10)
        self.move_in_direction(self.speed)
        detect_border(self)
        if self.collides_with(player):
            self.to_remove = True
            player.vie = player.vie - 1
            sounds.eat.play()
        if player.argent % 5 == 0 and player.argent > 1:
            self.speed = player.argent - 2
        if player.vie == 0:
            self.speed = 0


class Argent(Actor):

    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ["fishtile_119"]

    def update(self):
        if self.collides_with(player):
            self.to_remove = True
            sounds.coin.play()
            player.argent = player.argent + 1


def detect_border(actor):
    if actor.x > WIDTH:
        actor.x = 0
    if actor.x < 0:
        actor.x = WIDTH
    if actor.y > HEIGHT:
        actor.y = 0
    if actor.y < 0:
        actor.y = HEIGHT


def retour_zero(actor, ennemi):
    actor.speed = 10
    actor.vie = 3
    actor.argent = 0
    actor = Player("fishtile_080", (WIDTH / 2, HEIGHT / 2))
    ennemi.speed = 2


def add_ennemi():
    if player.vie > 0:
        ennemi = Ennemi("fishtile_100",
                        (randint(0, WIDTH), randint(0, HEIGHT)))
        ennemis.append(ennemi)


def add_argent():
    if player.vie > 0:
        argent = Argent("fishtile_119",
                        (randint(0, WIDTH), randint(0, HEIGHT)))
        argents.append(argent)


music.play('fish')

player = Player("fishtile_080", (WIDTH / 2, HEIGHT / 2))
ennemis = [Ennemi('fishtile_100', (randint(0, WIDTH), randint(0, HEIGHT)))]
argents = [Argent('fishtile_119', (randint(0, WIDTH), randint(0, HEIGHT)))]

clock.schedule_interval(add_ennemi, 5.0)
clock.schedule_interval(add_argent, 3.0)


def draw():
    screen.fill('skyblue')
    for x in range(0, WIDTH, 1):
        screen.blit('fishtile_003', (x, HEIGHT - 64))
    player.draw()
    for ennemi in ennemis:
        ennemi.draw()
    if player.vie == 0:
        screen.draw.text("GAME OVER", (WIDTH / 2, HEIGHT / 2))
    for argent in argents:
        argent.draw()
    screen.draw.text("Vie: " + str(player.vie), (10, 10), fontsize=20)
    screen.draw.text("Argent: " + str(player.argent), (10, 30), fontsize=20)
    if player.vie == 0:
        screen.draw.text("GAME OVER", (WIDTH / 2, HEIGHT / 2))


def update():
    player.update()
    for ennemi in ennemis:
        ennemi.update()
    remove_actors(ennemis)
    for argent in argents:
        argent.update()
    remove_actors(argents)
