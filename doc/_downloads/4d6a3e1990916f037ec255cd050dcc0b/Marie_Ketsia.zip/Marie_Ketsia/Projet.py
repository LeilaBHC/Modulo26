from pgzhelper import *
from random import*


#Flèche par être que l'acteur peut récupérer pour tuer l'ennemi

TITLE = 'Catch the pizza'
WIDTH = 800
HEIGHT = 600
GRAVITY = 0.5


WORLD_MAP = [
    [0,0,0,0,0,0,0,0,5,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,1,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,5,0,0,0],
    [0,0,0,0,0,5,0,0,0,0,0,3,1,0,0],
    [0,0,0,0,0,2,0,0,0,0,0,0,0,0,0],
    [0,0,0,5,0,0,0,0,0,4,0,0,6,5,0],
    [0,4,0,3,0,0,0,1,1,1,0,0,1,1,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,6,0,0,0,0,0,0,5,0,0,0,0,0],
    [1,1,1,1,0,0,0,1,1,1,1,1,1,1,1],
]

TILE_SIZE = 70
ROWS = len(WORLD_MAP)
COLS = len(WORLD_MAP[0])
WIDTH = COLS*TILE_SIZE
HEIGHT = ROWS*TILE_SIZE

class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.vy = 0
        self.speed = 5
        self.vie = 3
        self.score = 0
        self.munition = 0

    def update(self):
        self.vy += GRAVITY

        if keyboard.a:
            self.x -= self.speed
            self.flip_x = True
        if keyboard.d:
            self.x += self.speed
            self.flip_x = False


        for platform in platforms:
            platform.check_collision_with_actor(self)


        if keyboard.space and self.vy == 0:
            self.vy = -10

        detect_border(self)

        for mouse in mice :
            if self.collides_with(mouse):
                self.vie -= 1
                sounds.splat.play()
                mouse.to_remove = True
                add_mouse()

        self.y += self.vy

def on_mouse_down(pos):
    if player.munition > 0:
        direction = player.angle_to(pos)
        epee = Epee('epee', (player.x, player.y), direction, WIDTH = 5)
        epees.append(epee)
        player.munition -= 1

class Mouse(Actor):
    def __init__(self, image, pos, max_distance_x, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.images = ['mouse', 'mouse_move']
        self.vy = 0
        self.speed = 2
        self.max_distance_x = max_distance_x
        self.distance_x = 0

    def update(self):
        self.vy += GRAVITY

        for platform in platforms:
            platform.check_collision_with_actor(self)

        self.x += self.speed
        self.y += self.vy
        self.distance_x += self.speed


        if not (0 <= self.distance_x <= self.max_distance_x):
            self.flip_x = not self.flip_x
            self.speed = -self.speed

        detect_border_mouse(self)

class Pizza(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        if player.collides_with(self):
            self.to_remove = True
            player.score += 1
            sounds.coin.play()

class Epee(Actor):
    def __init__(self, image, pos, direction, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.direction = direction
        self.angle = direction
        self.speed = 10

    def update(self):
        self.move_in_direction(self.speed)
        for mouse in mice:
            if self.collides_with(mouse):
                print('SLAAASH')
                mouse.to_remove = True
                self.to_remove = True
                add_mouse()

class Munition(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)

    def update(self):
        if player.collides_with(self):
            self.to_remove = True
            player.munition += 1
            sounds.coin.play()
            player.vie += 1

player = Player('alienyellow_walk1', (WIDTH/2, HEIGHT/2-100))
platforms = []
music.play('italie')

mice = []
pizzas = []
epees = []
munitions = []
for row in range(ROWS):
    for col in range(COLS):
        pos = (col*TILE_SIZE+TILE_SIZE/2, row*TILE_SIZE+TILE_SIZE/2)
        if WORLD_MAP[row][col] == 1:
            platform = Platform('comptoir', pos, width=TILE_SIZE)
            platforms.append(platform)
        elif WORLD_MAP[row][col] == 2:
            platform = Platform('comptoir', pos, solid=True, width=TILE_SIZE)
            platforms.append(platform)
        elif WORLD_MAP[row][col] == 3:
            platform = Platform('comptoir', pos, solid=True, sticky=True, width=TILE_SIZE)
            platforms.append(platform)
        elif WORLD_MAP[row][col] == 4:
            mouse = Mouse('mouse', pos, max_distance_x=300)
            mice.append(mouse)
        elif WORLD_MAP[row][col] == 5:
            pizza = Pizza('pizza', pos, width=50)
            pizzas.append(pizza)
        elif WORLD_MAP[row][col] == 6:
            munition = Munition('epee', pos, width=50)
            munitions.append(munition)

def add_mouse():
        mouse = Mouse("mouse", (randint(0, WIDTH), randint(0, HEIGHT/2)), max_distance_x=300)
        mice.append(mouse)

def detect_border(actor):
    if actor.x < 0:
        actor.x = WIDTH
    if actor.x > WIDTH:
        actor.x = 0
    if actor.y > HEIGHT:
        actor.vie = 0

def detect_border_mouse(actor):
    if actor.x < 0:
        actor.x = WIDTH
    if actor.x > WIDTH:
        actor.x = 0
    if actor.y > HEIGHT:
        actor.to_remove = True
        add_mouse()

def draw():
    if player.vie > 0:
        background = pygame.image.load("images/images_cuisine.jpeg")
        background = pygame.transform.scale(background, (WIDTH, HEIGHT))
        screen.blit(background, (0, 0))
        screen.draw.text("Vie:" + str(player.vie), (1,15))
        screen.draw.text("Score:" + str(player.score), (1,30))
        screen.draw.text("Munition:" + str(player.munition), (1,45))
        for mouse in mice:
            mouse.draw()
        for platform in platforms: # On dessine toutes nos plateformes
            platform.draw()
        player.draw()
        for pizza in pizzas:
            pizza.draw()
        for epee in epees:
            epee.draw()
        for munition in munitions:
            munition.draw()

    else :
        screen.fill("black")
        screen.draw.text("GAME OVER", center=(WIDTH/2, HEIGHT/2))
        screen.draw.text("Score:" + str(player.score), center=(WIDTH/2, HEIGHT/2 +20))
    if player.score == 6 :
        screen.fill("deeppink")
        screen.draw.text("YOU WIN !", center=(WIDTH/2, HEIGHT/2), color = "black")




def update():
    player.update()
    for mouse in mice :
        mouse.update()
    for pizza in pizzas:
        pizza.update()
    for epee in epees:
        epee.update()
    for munition in munitions :
        munition.update()

    remove_actors(mice)
    remove_actors(pizzas)
    remove_actors(munitions)
    remove_actors(epees)
