
# changer les fonds et son




from pgzhelper import*
from random import*

TITLE = "Hit! fly edition"

WIDTH = 800
HEIGHT = 600

class Player(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed = 2
        self.images = ["fly1", "fly2"]
        self.score = 0
        self.life = 5

    def update(self):
        if keyboard.a:
            self.x -=self.speed
            self.flip_x = True
        if keyboard.d:
            self.x +=self.speed
            self.flip_x = False
        if keyboard.w:
            self.y -=self.speed
        if keyboard.s:
            self.y +=self.speed

        detect_border(self)


class Ennemy(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed=2
        self.direction = self.angle_to(player)
        self.images=["bee", "bee2"]
    def update(self):
        self.move_in_direction(self.speed)
        self.direction = self.angle_to(player)
        detect_border(self)
        if self.collides_with(player):
                sounds.splat.play()
                self.to_remove = True
                player.life -= 1

        if -90 < self.direction < 90 :
            self.flip_x =True
        else :
            self.flip_x = False

class Boss(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed=0.5
        self.direction = self.angle_to(player)
        self.images=["worm1", "worm2"]
        self.life=50
    def update(self):
        self.move_in_direction(self.speed)
        self.direction = self.angle_to(player)
        detect_border(self)
        if self.collides_with(player):
                sounds.eep.play()
                player.life -= 1

        if self.life <= 0 :
            sounds.splat.play()
            self.to_remove = True

        if -90 < self.direction < 90 :
            self.flip_x =True
        else :
            self.flip_x = False
        for missile in missiles :
            if self.collides_with(missile):
                self.life -=1
                sounds.splat.play()
                missile.to_remove = True


class Missile(Actor):
    def __init__(self, image, pos, direction, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.direction = direction # La direction initiale dépendra de la valeur donnée lors de la création du missile
        self.speed = 5
        self.angle = direction
        self.images=["eyes1", "eyes2","eyes3", "eyes4"]

    def update(self):
        self.move_in_direction(self.speed)
        for ennemy in ennemies :
            if self.collides_with(ennemy):
                sounds.explosion.play()
                ennemy.to_remove = True
                self.to_remove = True
                player.score += 1

class Stone(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.direction = self.angle_to(player)
        self.speed = 5
        self.images=["stone1.png", "stone2.png","stone3.png", "stone4.png"]

    def update(self):
        self.move_in_direction(self.speed)
        if self.collides_with(player):
            player.life -= 1
            sounds.explosion.play()
            self.to_remove = True

class Bonus(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.speed=0
    def update(self):
        if self.collides_with(player):
                sounds.meow2.play()
                self.to_remove = True
                player.life += 5


def detect_border(actor):
    if actor.x < 0:
        actor.x=WIDTH
    if actor.x > WIDTH:
        actor.x=0
    if actor.y < 0:
        actor.y=HEIGHT
    if actor.y > HEIGHT:
        actor.y=0

def on_mouse_down(pos):
    direction= player.angle_to(pos)
    missile = Missile("eyes1", (player.x, player.y), direction,width=20)
    missiles.append(missile)

def add_ennemy():
    if player.score<20:
        ennemy= Ennemy("bee",(randint(0,WIDTH), randint(0,HEIGHT)),width=50)
        ennemies.append(ennemy)

def add_stone():
    if player.score>=20:
        stone= Stone("stone1.png",(boss.x, boss.y),width=25)
        stones.append(stone)

def add_bonus():
    bonus= Bonus("missile",(randint(0,WIDTH), randint(0,HEIGHT)))
    bonnus.append(bonus)


player= Player("fly1",(WIDTH/2,HEIGHT/2))
boss= Boss("worm1",(WIDTH/2,10),width=100)




ennemies = []
missiles = []
bonnus = []
stones =[]

clock.schedule_interval(add_ennemy, 1)
clock.schedule_interval(add_bonus, 10)
clock.schedule_interval(add_stone, 0.3)

music.play("a")


def draw():
    if player.life>0:

        if boss.life>0:


            if player.score <20 :
                screen.blit("grass",(0,0))
                screen.draw.text(f"Score: {player.score}/20", (100, 0))
            else :
                background = pygame.image.load("images/bleu.png")
                if not music.is_playing("b"):
                    music.play("b")
                background = pygame.transform.scale(background, (WIDTH, HEIGHT))
                screen.blit(background,(0,0))
                screen.draw.text(f"Vie du ver: {boss.life}", (100, 0))
                if not boss.to_remove :
                    boss.draw()
                    boss.animate()
                    for stone in stones:
                        stone.draw()
                        stone.animate()


            player.draw()
            screen.draw.text(f"Vie: {player.life}", (0, 0))
            player.animate()
            for ennemy in ennemies :
                ennemy.draw()
                ennemy.animate()
            for bonus in bonnus :
                bonus.draw()
            for missile in missiles:
                missile.draw()
                missile.animate()
        else :
            screen.fill("gold")
            screen.draw.text(f"BRAVO !!!! :)", center=(400,300))




    else :
        screen.fill("pink")
        screen.draw.text(f"Game over :)", center=(400,300))

def update():
    player.update()
    for ennemy in ennemies :
        ennemy.update()
    for missile in missiles:
        missile.update()
    for bonus in bonnus :
        bonus.update()
    if player.score >=20 :
        if not boss.to_remove :
            boss.update()
            for stone in stones:
                    stone.update()


    remove_actors(ennemies)
    remove_actors(missiles)
    remove_actors(bonnus)
    remove_actors(stones)
