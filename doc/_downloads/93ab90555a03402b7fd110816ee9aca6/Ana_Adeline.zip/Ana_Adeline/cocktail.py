import pgzrun
from pgzhelper import *
from random import *
'sources: chat gpt'
'feuille de triche sur python'
'beaucoup Monsieur Gürtler (merci)'
'internet (on a pas noté les sites pardon...)'

TITLE = 'cocktail'

WIDTH = 1160
HEIGHT = 896

music.play('lofi')
class Barmanette(Actor):
    def __init__(self, image, pos, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.image = 'barmanette'
        self.speed = 3
        self.score = 0
        self.ingredientsramasses = []
        self.game_over = False

    def update(self):
        if self.game_over:
            return
        if keyboard.j:
            self.x -= self.speed
        if keyboard.l:
            self.x += self.speed
        if keyboard.i:
            self.y -= self.speed
        if keyboard.k:
            self.y += self.speed


class Ingredient(Actor):
    def __init__(self, image, pos, type, box, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.type = type
        self.box = box


class Tapi(Actor):
    def __init__(self, image, pos, type, box, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.type = type
        self.box = box


ingredients = [
    Ingredient('ingredient1', (0, 0), 1, ((646, 30), (766, 175))),
    Ingredient('ingredient2', (0, 0), 2, ((799, 30), (930, 175))),
    Ingredient('ingredient3', (0, 0), 3, ((945, 30), (1085, 175))),
    Ingredient('ingredient4', (0, 0), 4, ((646, 270), (780, 350))),
    Ingredient('ingredient5', (0, 0), 5, ((646, 270), (930, 350))),
    Ingredient('ingredient6', (0, 0), 6, ((646, 270), (1140, 350))),
    Ingredient('ingredient7', (0, 0), 7, ((55, 490), (250, 770)))
]

tapis = [
    Tapi('tapi', (0, 0), 8, ((410, 710), (755, 860))),
]


class Commande(Actor):
    def __init__(self, image, pos, ingredients, **kwargs):
        super().__init__(image, pos, **kwargs)
        self.ingredients = ingredients  # Liste des types d'ingrédients pour cette commande


def nouvelle_commande():
    # Retourne une liste de 3 ingrédients différents choisis aléatoirement parmi 1 à 7
    return sample(range(1, 8), 3)


commandes = [
    Commande('commande', (0, 0), nouvelle_commande())
]

barmanette = Barmanette('barmanette', (WIDTH / 2, HEIGHT / 2))


def on_mouse_down(pos, button):
    if button == 1:
        x, y = pos

        # Ramassage ingrédients
        for ingredient in ingredients:
            left, top = ingredient.box[0]
            right, bottom = ingredient.box[1]
            if left <= x <= right and top <= y <= bottom:
                if len(barmanette.ingredientsramasses) < 3:
                    print(f"Ramassé ingrédient {ingredient.type} à {pos}")
                    barmanette.ingredientsramasses.append(ingredient.type)
                else:
                    print("Tu as déjà 3 ingrédients. Pose-les avant d'en ramasser d'autres.")
                return  # Ne ramasse qu’un ingrédient par clic

        # Déposer ingrédients sur tapis
        for t in tapis:
            left, top = t.box[0]
            right, bottom = t.box[1]
            if left <= x <= right and top <= y <= bottom:
                if len(barmanette.ingredientsramasses) == 3:
                    # Vérifie si la liste d'ingrédients correspond à une commande
                    match_trouvee = False
                    for commande in commandes:
                        if sorted(barmanette.ingredientsramasses) == sorted(commande.ingredients):
                            match_trouvee = True
                            barmanette.score += 1
                            barmanette.ingredientsramasses.clear()
                            commande.ingredients = nouvelle_commande()
                            print("Commande réussie ! Score +1")
                            break
                    if not match_trouvee:
                        barmanette.game_over = True
                        print("Ingrédients incorrects. Game Over!")
                else:
                    print(f"Tu dois avoir 3 ingrédients pour déposer, tu en as {len(barmanette.ingredientsramasses)}.")
                return



def draw():
    screen.blit('fond', (0, 0))
    barmanette.draw()
    screen.blit('comptoir', (0, 0))
    screen.blit('tapi', (0, 0))
    for ingredient in ingredients:
        ingredient.draw()
    for commande in commandes:
        commande.draw()

    screen.draw.text(f'Score: {barmanette.score}', (320, 135), color=(0, 0, 0), fontsize=50)

    # Affiche les ingrédients demandés sous le score
    if commandes:
        ing_text = "Commande: " + ", ".join(str(i) for i in commandes[0].ingredients)
        screen.draw.text(ing_text, (270, 240), color=(0, 0, 0), fontsize=40)

    if barmanette.game_over:
        screen.draw.text("Game Over!", (WIDTH / 2 - 200, HEIGHT / 2), color=(255, 0, 0), fontsize=100)


def update():
    # Positions fixes (à garder ou adapter si besoin)
    ingredients[0].topleft = (0, 0)
    ingredients[1].topleft = (0, 0)
    ingredients[2].topleft = (0, 0)
    ingredients[3].topleft = (0, 0)
    ingredients[4].topleft = (0, 0)
    ingredients[5].topleft = (0, 0)
    ingredients[6].topleft = (0, 0)
    commandes[0].topleft = (0, 0)

    if not barmanette.game_over:
        barmanette.update()


pgzrun.go()