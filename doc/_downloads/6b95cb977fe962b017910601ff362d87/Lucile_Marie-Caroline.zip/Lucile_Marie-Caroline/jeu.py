import pgzrun
from pgzrun import *
from pgzhelper import *
from random import *

game_over_sound = sounds.die # son du game over
music.play('wind') # musique de fond
music.set_volume(0.5) #volume entre 0 et 1

TITLE = 'Flappy Bird'
WIDTH = 285
HEIGHT = 500

accueil = True  # état initial : on est sur la page d'accueil

#variable pour le message de game over
message_opacity = 0
message_visible = False
message_timer = 0
show_message_duration = 4 #le message reste 4 secondes

class Player(Actor):
    def __init__(self, color_prefix, pos):
        super().__init__(color_prefix + '-mid', pos)
        #animation de l'image selon la couleur choisie
        self.images = [color_prefix + '-mid', color_prefix + '-down', color_prefix + '-up'] #animer le bird
        self.vy = 0
        self.game_over = False
        self.score = 0
        self.sound_played = False # éviter de jouer le son plusieurs fois
        self.animation_index = 0

    def update(self):
        self.y += self.vy
        self.vy += 1

        if not obstaclebas.scored and self.x > obstaclebas.x + obstaclebas.width:#compter le score si le bird passe le tuyau du bas
            self.score += 1
            obstaclebas.scored = True

        if self.y > 600:#limite au sol
            self.y = 600
            self.vy = 0

        if self.y > 550 or self.y < -10: # game over si le bird sort de l'écran
            if not self.game_over:
                self.game_over = True
                if not self.sound_played:
                    music.stop()#coupe la musique de fond
                    game_over_sound.play()
                    self.sound_played = True

        if self.collide_pixel(obstaclebas) or self.collide_pixel(obstaclehaut): # game over si le bird touche les tuyaux
            if not self.game_over:
                self.game_over = True
                if not self.sound_played:
                    music.stop()#coupe la musique de fond
                    game_over_sound.play()
                    self.sound_played = True

        if keyboard.space: # saut du bird avec espace
            self.vy = -7

    def animate(self):  # <--- AJOUT ICI
        if not hasattr(self, 'animation_index'):
            self.animation_index = 0
        self.animation_index += 0.2
        if self.animation_index >= len(self.images):
            self.animation_index = 0
        self.image = self.images[int(self.animation_index)]


class Obstaclebas(Actor):
    def __init__(self, image, pos):
        super().__init__(image, pos)
        self.scored = False #indique si le tuyau a déjà compté un point

    def update(self):
        self.x -= 7 #vitesse des obstacles bas
        if self.x < -50:
            self.x = 300 #où apparait l'obstale > distance entre les obstacles bas
            self.y = randint(350 ,550)  # hauteur des obstacles randomisée
            self.scored = False

class Obstaclehaut(Actor):
    def __init__(self, image, pos):
        super().__init__(image, pos)

    def update(self):
        self.x -= 7 #vitesse des obstacles haut
        if self.x < -50:
            self.x = 300  #ou apparait l'obstale > distance entre les obstacles haut
            self.y = randint(-100 , -50) #hauteur des obstacles randomisée

def reset_game(): # fonction pour redémarrer le jeu et la musique de fond
    global message_visible, message_opacity, message_timer, accueil

    bird_color = choice(['bb','rb','yb']) #choisir une nouvelle couleur aléatoire pour le bird

    player.image = bird_color + '-mid'
    player.images = [bird_color + '-mid', bird_color + '-down', bird_color + '-up']
    player.pos=(WIDTH/ 2, HEIGHT / 2)
    player.vy = 0
    player.game_over = False
    player.score = 0
    player.sound_played = False
    player.animation_index = 0

    obstaclebas.x, obstaclebas.y = 300, 480
    obstaclebas.scored = False
    obstaclehaut.x, obstaclehaut.y = 300, -50

    music.play('wind')

    message_visible = False
    message_opacity = 0
    message_timer = 0

    accueil = True

#création des objets
bird_color_init = choice (['bb','rb','yb'])
player = Player(bird_color_init, (WIDTH/2, HEIGHT/2))
obstaclebas = Obstaclebas(choice(['pipe-greenbas', 'pipe-redbas']), (300, 480))
obstaclehaut = Obstaclehaut(choice(['pipe-greenhaut','pipe-redhaut']), (300,-50))

def draw():
    screen.clear()

    if accueil:
        screen.blit('background-jour', (0, 0))
        screen.blit("message", (50, 110)) #image de page d'accueil
        return

    screen.blit('background-jour', (0, 0))
    player.draw()
    obstaclehaut.draw()
    obstaclebas.draw()
    screen.draw.text(f'Score: {player.score}', (15, 10), color=(0, 0, 0), fontsize=30)  # Affichage du score

    if player.game_over:
        screen.blit('gameover', (45,110))

        if message_visible and message_opacity > 0:
            s = pygame.Surface((WIDTH, 30), pygame.SRCALPHA)
            text = "R pour rejouer !"
            font = pygame.font.SysFont("arial", 24)
            rendered = font.render(text, True, (255, 165, 0))
            rendered.set_alpha(int(message_opacity))
            s.blit(rendered, (WIDTH // 2 - rendered.get_width() // 2, 0))
            screen.surface.blit(s, (0, 400))

def update():
    global accueil, message_visible, message_opacity, message_timer

    if accueil:
        if keyboard.space :
            accueil = False # sortir de la page d'accueil
        return

    if not player.game_over:
        player.update()
        player.animate()
        obstaclehaut.update()
        obstaclebas.update()
        message_visible = False
        message_opacity = 0
        message_timer = 0

    else:
        if not message_visible:
            message_visible = True
            message_opacity = 0
            message_timer = 0

        if message_visible:
            # Apparition du message
            if message_timer < show_message_duration:
                if message_opacity < 255:
                    message_opacity += 5
                message_timer += 1 / 60
            else:
                # Disparition du message
                if message_opacity > 0:
                    message_opacity -= 5

        # Redémarrage si l'espace est appuyé pendant l'affichage du message
        if keyboard.r:
            reset_game()

pgzrun.go()